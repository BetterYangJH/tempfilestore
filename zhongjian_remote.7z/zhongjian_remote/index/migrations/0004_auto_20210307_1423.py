# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0003_auto_20210307_1401'),
    ]

    operations = [
        migrations.AddField(
            model_name='nodeinfo',
            name='finishTime',
            field=models.IntegerField(verbose_name='完成时间', null=True),
        ),
        migrations.AddField(
            model_name='scheduleinfo',
            name='finishTime',
            field=models.IntegerField(verbose_name='完成时间', null=True),
        ),
    ]
