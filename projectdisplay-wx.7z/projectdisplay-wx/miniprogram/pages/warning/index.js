Page({
  data: {
    year: 0,
    month: 0,
    day:0,
    date: ['日', '一', '二', '三', '四', '五', '六'],
    dateArr: [],
    isToday: 0,
    isTodayWeek: false,
    todayIndex: 0,
    cur_month_node:{
      total:5,
      alread:2,
      ontime:2,
      undone:5
    },
    click_date:"",
    add_memo:"",
    // 当月预警信息，
    // 状态信息：-1 未完成 0 延期完成 1 已完成
    memo_mes:[
      {
        date:"2020.11.13",
        total_status:"rgba(255,153,51,0.795)",
        memo:[
          {
            status:-1,
            msg:"办公区临设工程"
          },
          {
            status:0,
            msg:"工友村临设工程"
          },
          {
            status:1,
            msg:"围挡封闭"
          },
          {
            status:1,
            msg:"现场三通一平"
          },
        ]
      },
      {
        date:"2020.11.14",
        total_status: "rgba(19, 204, 149, 0.795)",
        memo: [
        {
          status: 1,
          msg: "基坑支护"
        },
        {
        status: 1,
        msg: "基坑开挖"
        },
        {
        status: 1,
        msg: "基础施工"
        },
        {
        status: 1,
        msg: "底板浇筑"
        }
      ]
      }
    ],
    cur_mes:"",
    date_color:""
  },
  onLoad: function () {
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    var memo_mes = wx.getStorageSync('memo')
    if(memo_mes==""){
      memo_mes=this.data.memo_mes
    }
    // 设置含有预警事件日期按钮变色
    var date_color = {}

    for (var item in memo_mes){
      // date_color[date_color.length] = [memo_mes[item].date,]
      // date_color[memo_mes[item].total_status].push(memo_mes[item].date) 
      console.log(memo_mes[item].date,"----")
      date_color[String(memo_mes[item].date)]=memo_mes[item].total_status
    }
    console.log(date_color)
    this.dateInit();
    this.setData({
      year: year,
      month: month,
      day: now.getDate(),
      isToday: '' + year +"."+ month +"."+ now.getDate(),
      memo_mes:memo_mes,
      date_color:date_color
    })
  
  },
  dateInit: function (setYear, setMonth) {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = [];                       //需要遍历的日历数组数据
    let arrLen = 0;                         //dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();                 //没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 1 : (month + 1);
    let startWeek = new Date(year + ',' + (month + 1) + ',' + 1).getDay();                          //目标月1号对应的星期
    let dayNums = new Date(year, nextMonth, 0).getDate();               //获取目标月有多少天
    let obj = {};
    let num = 0;
    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    arrLen = startWeek + dayNums;
    for (let i = 0; i < arrLen; i++) {
      if (i >= startWeek) {
        num = i - startWeek + 1;
        obj = {
          isToday: '' + year + "." + (month + 1) + "." + num,
          dateNum: num,
          weight: 5
        }
      } else {
        obj = {};
      }
      dateArr[i] = obj;
    }
    this.setData({
      dateArr: dateArr
    })
    console.log(dateArr)
    let nowDate = new Date();
    let nowYear = nowDate.getFullYear();
    let nowMonth = nowDate.getMonth() + 1;
    let nowWeek = nowDate.getDay();
    let getYear = setYear || nowYear;
    let getMonth = setMonth >= 0 ? (setMonth + 1) : nowMonth;
    if (nowYear == getYear && nowMonth == getMonth) {
      this.setData({
        isTodayWeek: true,
        todayIndex: nowWeek
      })
    } else {
      this.setData({
        isTodayWeek: false,
        todayIndex: -1
      })
    }
  },
  // /**
  //  * 上年切换
  //  */
  // lastYear: function () {
  //   //全部时间的月份都是按0~11基准，显示月份才+1
  //   let year = this.data.year - 1;
  //   let month = this.data.month;
  //   this.setData({
  //     year: year,
  //     // month: (month + 1)
  //   })
  //   this.dateInit(year, month);
  // },
  // /**
  //  * 下年切换
  //  */
  // nextYear: function () {
  //   //全部时间的月份都是按0~11基准，显示月份才+1
  //   let year = this.data.year + 1;
  //   let month = this.data.month;
  //   this.setData({
  //     year: year,
  //     // month: (month + 1)
  //   })
  //   this.dateInit(year, month);
  // },




  /**
   * 上月切换
   */
  lastMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  },
  /**
   * 下月切换
   */
  nextMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  },



  clickdate: function (e) {
    var that =this
    console.log(e)
    var year = String(e.currentTarget.dataset.year)
    var month = String(e.currentTarget.dataset.month)
    var datenum = String(e.currentTarget.dataset.datenum)
    var bind_time = year+"."+month+"."+datenum

    console.log(bind_time)
    this.setData({
      click_date: bind_time
    })

    console.log(that.data.memo_mes)
    var i
    var len = that.data.memo_mes.length
    for(i=0;i<len;i++){
      if (that.data.memo_mes[i].date==bind_time){
        console.log(that.data.memo_mes[i].memo)
        this.setData({
          cur_mes:that.data.memo_mes[i].memo
        })
        break
      }
      else{
        this.setData({
          cur_mes:""
        })
      }
    }
  },

  addmemo:function () {
    // console.log(this.data.click_date)
    this.showModal()
  },
getmemo:function (e) {
  console.log(e.detail.value)
  // var tmp = this.data.memo_mes
  if(e.detail.value != ""){
    var add_memo={
      date:this.data.click_date,
      memo:e.detail.value
    }
  
    this.setData({
      add_memo:add_memo
    })

  }
},

  changeok:function () {
    this.hideModal()
    this.setData({
      memo_mes: this.data.memo_mes.concat(this.data.add_memo)
    })
    console.log(this.data.memo_mes)
    wx.setStorageSync('memo', this.data.memo_mes)
  },

  //显示对话框
  showModal: function () {
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
})