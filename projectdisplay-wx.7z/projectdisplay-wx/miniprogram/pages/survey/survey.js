// pages/survey/survey.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        tableMes: [
            [{
                    "name": "项目名称",
                    "value": "中山大学·深圳建设工程项目施工总承包（Ⅱ标）"
                },
                {
                    "name": "所属业态",
                    "value": "住宅、商业、学校"
                },
                {
                    "name": "建筑面积",
                    "value": 42
                },
                {
                    "name": "占地面积",
                    "value": 62
                },
                {
                    "name": "合同额",
                    "value": 24.79
                },
                {
                    "name": "合同工期",
                    "value": 963
                }
            ],
            [{
                    "l1": "建设单位",
                    "l2": "深圳市住宅工程管理站xxxxxxxxxxxxxxx",
                    "l3": "王鑫",
                    "l4": "15979005263"
                },
                {
                    "l1": "监理单位",
                    "l2": "浙江江南工程管理股份有限公司",
                    "l3": "许建华",
                    "l4": "13336051039"
                },
                {
                    "l1": "咨询单位",
                    "l2": "浙江江南工程管理股份有限公司",
                    "l3": "李冬",
                    "l4": "13456903636"
                },
                {
                    "l1": "勘察单位",
                    "l2": "深圳市工勘岩土集团有限公司",
                    "l3": "陈强",
                    "l4": "13760306585"
                },
                {
                    "l1": "设计单位",
                    "l2": "深圳市华阳国际工程设计有限公司",
                    "l3": "李祥柱",
                    "l4": "13425157699"
                },
            ]
        ],

        showModalStatus: false,
        wait_change_i: 0,
        dialog_mes: "",
        dialog_value: "",
        save_flag: false,
        changed_data: "",
        old_value: ""

    },


    callphone: function(e) {
        console.log(e.currentTarget.dataset.phnum)
        wx.makePhoneCall({
            phoneNumber: e.currentTarget.dataset.phnum,
        })

    },

    change: function(e) {
        // console.log(e.currentTarget.dataset.index,"============")
        // console.log(e.currentTarget.dataset.statu)
        var wait_change_index = e.currentTarget.dataset.index
        var currentStatu = e.currentTarget.dataset.statu;
        var tmp_list = this.data.tableMes
        if (e.currentTarget.dataset.statu == "changeok") {
            currentStatu = "close"
                // console.log(this.data.save_flag)
                // console.log(this.data.old_value,"+++++++++++++++")
                // console.log(this.data.changed_data,"+++++++++``````````````````++++++")
            if (this.data.changed_data == "") {
                var i = e.currentTarget.dataset.i
                tmp_list[0][i].value = this.data.old_value
                this.setData({
                    tableMes: tmp_list
                })
            }
            if (this.data.save_flag) {
                var i = e.currentTarget.dataset.i
                tmp_list[0][i].value = this.data.changed_data
                this.setData({
                    tableMes: tmp_list,
                    save_flag: false
                })


            }

        }
        this.util(wait_change_index, currentStatu)


    },
    // 自定义弹窗修改动画
    util: function(wait_change_index, currentStatu) {
        if (wait_change_index != "" && wait_change_index != "ok") {
            this.setData({
                wait_change_i: wait_change_index,
                old_value: this.data.tableMes[0][wait_change_index].value
            })
        }
        /* 动画部分 */
        // 第1步：创建动画实例 
        var animation = wx.createAnimation({
            duration: 200, //动画时长 
            timingFunction: "linear", //线性 
            delay: 0 //0则不延迟 
        });

        // 第2步：这个动画实例赋给当前的动画实例 
        this.animation = animation;

        // 第3步：执行第一组动画 
        animation.opacity(0).rotateX(-100).step();

        // 第4步：导出动画对象赋给数据对象储存 
        this.setData({
            animationData: animation.export()
        })

        // 第5步：设置定时器到指定时候后，执行第二组动画 
        setTimeout(function() {
            // 执行第二组动画 
            animation.opacity(1).rotateX(0).step();
            // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象 
            this.setData({
                animationData: animation
            })

            //关闭 
            if (currentStatu == "close") {
                this.setData({
                    showModalStatus: false,
                    save_flag: false
                });
            }
        }.bind(this), 200)

        // 显示 
        if (currentStatu == "open") {
            this.setData({
                showModalStatus: true
            });
        }
    },

    change_value: function(e) {
        // console.log(e.detail.value,"~~~~~~~~~~~")

        this.setData({
            changed_data: e.detail.value,
            save_flag: true
        })

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})