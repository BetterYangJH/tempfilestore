from django.db import models
import django.utils.timezone as timezone
class BaseModel(models.Model):
    """
        基础模型，共用字段
    """
    insertData = models.DateTimeField(auto_now_add=True, verbose_name="数据创建时间")
    updateData = models.DateTimeField(verbose_name="数据最新修改时间", db_index=True,default = timezone.now)

    class Meta:
        abstract = True

class ProjectInfo(BaseModel):
    """
    项目信息
    """
    projectID = models.IntegerField(verbose_name="项目编号", null=False, unique=True, db_index=True, primary_key=True)
    projectName = models.CharField(verbose_name="项目名称",  null=False,max_length=40)
    projectFormats = models.CharField(verbose_name="所属业态", null=False,max_length=20)
    barea = models.FloatField(verbose_name="建筑面积", null=False)
    carea = models.FloatField(verbose_name="占地面积", null=False)
    amount = models.FloatField(verbose_name="合同金额", null=False)
    duration = models.IntegerField(verbose_name="合同工期",null=False)
    conUnit = models.CharField(verbose_name="建设单位", null=False,max_length=20)
    supUnit = models.CharField(verbose_name="监理单位", null=False,max_length=20)
    advUnit = models.CharField(verbose_name="咨询单位", null=False,max_length=20)
    surUnit = models.CharField(verbose_name="勘察单位", null=False,max_length=20)
    desUnit = models.CharField(verbose_name="设计单位", null=False,max_length=20)
    conCommDate = models.IntegerField(verbose_name="合同开工日期",null=True)
    conCompDate = models.IntegerField(verbose_name="合同竣工日期",null=True)
    awarDate = models.IntegerField(verbose_name="中标通知书日期",null=True)
    commDate = models.IntegerField(verbose_name="开工令日期",null=True)
    permitDate = models.IntegerField(verbose_name="施工许可证日期",null=True)
    continueDate = models.IntegerField(verbose_name="竣工顺延日期",null=True)
    state = models.CharField(verbose_name="在建状态", null=False, db_index=True,default='prepare',max_length=10)
    deleted = models.BooleanField(verbose_name="是否删除", null=False, default=0)
    projectManager = models.IntegerField(verbose_name="项目经理",null=True)
    class Meta:
        db_table = 'PROJECT_INFO'
        verbose_name = '项目概况'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.projectID)+' - '+self.projectName

class NoticeInfo(BaseModel):
    """
        项目滚动消息
    """
    noticeID = models.IntegerField(verbose_name="消息编号", null=False, unique=True, db_index=True, primary_key=True)
    noticeMsg = models.CharField(verbose_name="消息内容",  null=True, max_length=40)
    projectID = models.IntegerField(verbose_name="项目编号", null=False)
    class Meta:
        db_table = 'Notice_Info'
        verbose_name = '项目滚动消息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.noticeID)+' - '+self.noticeMsg

class UnitsInfo(BaseModel):
    """
    参建单位信息
    """
    unitsID = models.IntegerField(verbose_name="参加单位编号", null=False, unique=True, db_index=True, primary_key=True)
    unitsName = models.CharField(verbose_name="单位名称",  null=False,max_length=20)
    contect = models.CharField(verbose_name="联系人", null=False, max_length=10)
    tel = models.CharField(verbose_name="电话", null=False, max_length=14)
    class Meta:
        db_table = 'UNITS_INFO'
        verbose_name = '参建单位信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.unitsID)+' - '+self.unitsName

class RelationInfo(BaseModel):
    """
    人员项目关联信息
    """
    relationID = models.IntegerField(verbose_name="关联关系编号", null=False, unique=True, primary_key=True)
    userID = models.IntegerField(verbose_name="人员编号", null=False, db_index=True)
    projectID = models.IntegerField(verbose_name="项目编号", null=False)

    class Meta:
        db_table = 'RELATION_INFO'
        verbose_name = '人员项目关联信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.userID)+' - '+str(self.projectID)

class ImageInfo(BaseModel):
    """
    图片信息
    """
    imgID = models.IntegerField(verbose_name="图片编号",null=False, unique=True, primary_key=True)
    imgPath = models.CharField(verbose_name="图片路径", null=False,max_length=120)
    mapID = models.BigIntegerField(verbose_name="所属编号", null=False, db_index=True)
    class Meta:
        db_table = 'IMAGE_INFO'
        verbose_name = '图片信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.imgID)


# 单体模块
class SegmentInfo(BaseModel):
    """
    标段信息
    """
    segmentID = models.IntegerField(verbose_name="标段编号", null=False, unique=True, primary_key=True, db_index=True)
    segmentName = models.CharField(verbose_name="标段名称", null=False, max_length=10)
    projectID = models.IntegerField(verbose_name="所属项目", null=False, db_index=True)
    class Meta:
        db_table = 'SEGMENT_INFO'
        verbose_name = '标段信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.projectID)+' - '+self.segmentName

class BlockInfo(BaseModel):
    """
    地块信息
    """
    blockID = models.IntegerField(verbose_name="地块编号", null=False, unique=True, primary_key=True, db_index=True)
    blockName = models.CharField(verbose_name="地块名称",  null=False, max_length=10)
    segmentID = models.IntegerField(verbose_name="所属标段", null=False, db_index=True)
    class Meta:
        db_table = 'BLOCK_INFO'
        verbose_name = '地块信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.segmentID)+' - '+self.blockName

class SingleInfo(BaseModel):
    """
    单体模块
    """
    singleID = models.BigIntegerField(verbose_name="单体编号", null=False, unique=True, primary_key=True, db_index=True)
    singleName = models.CharField(verbose_name="单体名称",  null=False, max_length=20)
    blockID = models.IntegerField(verbose_name="所属地块", null=False, db_index=True)
    class Meta:
        db_table = 'SINGLE_INFO'
        verbose_name = '单体模块'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.blockID)+' - '+self.singleName

class BuildInfo(BaseModel):
    """
    楼栋信息
    """
    buildID = models.BigIntegerField(verbose_name="楼栋编号", null=False, unique=True, primary_key=True, db_index=True)
    buildName = models.CharField(verbose_name="楼栋名称",  null=False, max_length=10)
    respID = models.IntegerField(verbose_name="负责人编号", null=False)
    singleID = models.IntegerField(verbose_name="所属单体", null=False, db_index=True)
    class Meta:
        db_table = 'BUILDING_INFO'
        verbose_name = '楼栋信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.singleID)+' - '+self.buildName

# 计划管理
class PhaseInfo(BaseModel):
    """
    阶段信息
    """
    phaseID = models.BigIntegerField(verbose_name="阶段编号", null=False, unique=True, primary_key=True, db_index=True)
    phaseName = models.CharField(verbose_name="阶段名称",  null=False, max_length=10)
    singleID = models.BigIntegerField(verbose_name="所属单体", null=False, db_index=True)
    class Meta:
        db_table = 'PHASE_INFO'
        verbose_name = '阶段信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.singleID)+' - '+self.phaseName

class NodeInfo(BaseModel):
    """
    工期节点
    """
    nodeID = models.BigIntegerField(verbose_name="节点编号", null=False, unique=True, db_index=True, primary_key=True)
    nodeName = models.CharField(verbose_name="节点内容",  null=False, max_length=15)
    uploadPeople = models.IntegerField(verbose_name="上传员工", null=False, db_index=True)
    deadline = models.IntegerField(verbose_name="节点要求",null=False, db_index=True)
    finishState = models.BooleanField(verbose_name="是否完成", null=False, default=0)
    phaseID = models.BigIntegerField(verbose_name="所属阶段", null=False, db_index=True)
    finishTime = models.BigIntegerField(verbose_name="完成时间",null=True)
    right = models.IntegerField(verbose_name="权限级别",null=False, default=0)
    class Meta:
        db_table = 'NODE_INFO'
        verbose_name = '工期节点'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.phaseID)+' - '+self.nodeName


# 形象进度
class FloorInfo(BaseModel):
    """
    楼层信息
    """
    floorID = models.BigIntegerField(verbose_name="楼层编号", null=False, unique=True, primary_key=True, db_index=True)
    floorNum = models.IntegerField(verbose_name="楼层数",  null=False)
    buildID = models.BigIntegerField(verbose_name="所属楼栋", null=False, db_index=True)
    class Meta:
        db_table = 'FLOOR_INFO'
        verbose_name = '楼层信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.buildID)+' - '+str(self.floorNum)

class ModuleInfo(BaseModel):
    """
    模块信息
    """
    moduleID = models.BigIntegerField(verbose_name="模块编号", null=False, unique=True, primary_key=True, db_index=True)
    moduleName = models.CharField(verbose_name="模块名",  null=False, db_index=True, max_length=15)
    floorID = models.BigIntegerField(verbose_name="所属楼层", null=False, db_index=True)
    finishCount = models.IntegerField(verbose_name="完成数量", null=False)
    finishiTag = models.CharField(verbose_name="完成标志",  null=False, max_length=30, default='all')
    total = models.IntegerField(verbose_name="简报总数量", null=False)
    class Meta:
        db_table = 'MODULE_INFO'
        verbose_name = '模块信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.floorID)+' - '+str(self.moduleName)

class ScheduleInfo(BaseModel):
    """
    形象进度
    """
    scheduleID = models.BigIntegerField(verbose_name="形象进度编号", null=False, unique=True, primary_key=True, db_index=True)
    uploadPeople = models.IntegerField(verbose_name="上传员工", null=False, db_index=True)
    scheduleName = models.CharField(verbose_name="形象进度内容",  null=False, max_length=15)
    moduleID = models.BigIntegerField(verbose_name="所属模块", null=False, db_index=True)
    finishState = models.IntegerField(verbose_name="完成情况",  null=False,default=0)
    finishTime = models.BigIntegerField(verbose_name="提交时间",null=True)
    realFinishTime = models.BigIntegerField(verbose_name="实际完成时间",null=True)
    class Meta:
        db_table = 'SCHEDULE_INFO'
        verbose_name = '形象进度'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.moduleID)+' - '+self.scheduleName