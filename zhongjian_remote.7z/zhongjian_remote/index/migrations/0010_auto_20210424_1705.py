# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0009_moduleinfo_total'),
    ]

    operations = [
        migrations.AlterField(
            model_name='moduleinfo',
            name='finishiTag',
            field=models.CharField(verbose_name='完成标志', max_length=30, default='all'),
        ),
    ]
