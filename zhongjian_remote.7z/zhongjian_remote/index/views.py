
import datetime
import json
import traceback
from multiprocessing import Process
from django.shortcuts import render
from django.views.generic import View
from django.http import JsonResponse
from django.db import transaction
from .models import *
from user.models import DepartmentInfo,PositionInfo,UserInfo
from tools.get_info import *
from tools.token_tools import get_payload,get_right
from tools import log_tools

# 删除接口
class DeleteInfo(View):
    # 删除信息
    def get(self,request):
        try:
            token = request.GET.get('token','')
            ID = request.GET.get('id','')
            mode = request.GET.get('mode','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not ID or not mode:
            log_tools.log_param_error('删除信息',[token,ID,mode])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if isinstance(token,list):
            token = token[0]
        if isinstance(ID,list):
            ID = ID[0]
        if isinstance(mode,list):
            mode = mode[0]
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('删除信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            ID = int(ID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        if mode=='project': # 修改 项目 删除状态
            log_tools.log_request(user_info['username'],'删除项目(假删除)',request.GET)
            res = self.change_project_state(project_id=ID)
        elif mode=='projectRealDel': # 删除项目
            log_tools.log_request(user_info['username'],'删除项目(真删除)',request.GET)
            res = self.del_project(project_id=ID)
        elif mode=='segment': # 删除 标段-地块
            log_tools.log_request(user_info['username'],'删除 标段-地块',request.GET)
            res = self.del_segment(segement_id=ID)
        elif mode=='block': # 删除 地块-单体
            log_tools.log_request(user_info['username'],'删除 地块-单体',request.GET)
            res = self.del_block(block_id=ID)
        elif mode=='single': # 删除 单体-楼栋
            log_tools.log_request(user_info['username'],'删除 单体-楼栋',request.GET)
            res = self.del_single(single_id=ID)
        elif mode=='build': # 删除 楼栋-楼层-形象进度 楼栋-阶段-工程节点
            log_tools.log_request(user_info['username'],'删除 楼栋-楼层-形象进度 楼栋-阶段-工程节点',request.GET)
            res =  self.del_build(build_id=ID)
        elif mode=='delNode': # 删除 节点
            log_tools.log_request(user_info['username'],'删除 节点',request.GET)
            res = self.del_node(node_id=ID)
        elif mode=='node' or mode=='schedule': # 重置 节点 形象进度 完成状态
            log_tools.log_request(user_info['username'],'重置 节点 形象进度 完成状态',request.GET)
            res = self.change_finish_state(ID=ID,mode=mode)
        log_tools.log_response(res)
        return JsonResponse(res)
    # 删除项目
    def del_project(self,project_id):
        try:
            with transaction.atomic():
                ProjectInfo.objects.filter(projectID=project_id).delete()
                NoticeInfo.objects.filter(projectID=project_id).delete()
                UnitsInfo.objects.filter(unitsID__startswith=project_id).delete()
                RelationInfo.objects.filter(projectID=project_id).delete()
                ImageInfo.objects.filter(mapID=project_id).delete()
                segments = SegmentInfo.objects.filter(segmentID__startswith=project_id)
                for seg in segments:
                    res = self.del_segment(segement_id=seg.segmentID)
                segments.delete()
                deps = DepartmentInfo.objects.filter(departmentID__startswith=project_id)
                for dep in deps:
                    users = UserInfo.objects.filter(departmentID=dep.departmentID)
                    for user in users:
                        reset_user(user)
                deps.delete()
                PositionInfo.objects.filter(positionID__startswith=project_id).delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1304,"data":"ERROR: RealDelete project {} info error in {}".format(project_id,current_step)}
        return {"code":1204,"data":'SUCCESS: RealDelete project {} info seccess'.format(project_id)}
    # 假删除项目
    def change_project_state(self,project_id):
        try:
            project = ProjectInfo.objects.get(projectID=project_id)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1303,"data":"ERROR: Get data from db error"}
        try:
            project.deleted = True
            project.save()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1304,"data":"ERROR: Delete project {} info error".format(project_id)}
        return  {"code":1204,"data":'SUCCESS: Delete project {} info seccess'.format(project_id)}
    # 删除标段
    def del_segment(self,segement_id):
        try:
            with transaction.atomic():
                SegmentInfo.objects.filter(segmentID=segement_id).delete()
                BlockInfo.objects.filter(blockID__startswith=segement_id).delete()
                SingleInfo.objects.filter(singleID__startswith=segement_id).delete()
                PhaseInfo.objects.filter(phaseID__startswith=segement_id).delete()
                nodes = NodeInfo.objects.filter(nodeID__startswith=segement_id)
                for node in nodes:
                    ImageInfo.objects.filter(mapID=node.nodeID).delete()
                nodes.delete()
                builds = BuildInfo.objects.filter(buildID__startswith=segement_id)
                for build in builds:
                    res = self.del_build(build_id=build.buildID)
                builds.delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1305,"data":"ERROR: Delete segment error"}
        return {"code":1205,"data":"ERROR: Delete segment successfully"}
    # 删除地块
    def del_block(self,block_id):
        try:
            with transaction.atomic():
                BlockInfo.objects.filter(blockID=block_id).delete()
                SingleInfo.objects.filter(singleID__startswith=block_id).delete()
                PhaseInfo.objects.filter(phaseID__startswith=block_id).delete()
                nodes = NodeInfo.objects.filter(nodeID__startswith=block_id)
                for node in nodes:
                    ImageInfo.objects.filter(mapID=node.nodeID).delete()
                nodes.delete()
                builds = BuildInfo.objects.filter(buildID__startswith=block_id)
                for build in builds:
                    res = self.del_build(build_id=build.buildID)
                builds.delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1305,"data":"ERROR: Delete block error"}
        return {"code":1205,"data":"ERROR: Delete block successfully"}
    # 删除单体
    def del_single(self,single_id):
        try:
            with transaction.atomic():
                SingleInfo.objects.filter(singleID=single_id).delete()
                PhaseInfo.objects.filter(singleID=single_id).delete()
                nodes = NodeInfo.objects.filter(nodeID__startswith=single_id)
                for node in nodes:
                    ImageInfo.objects.filter(mapID=node.nodeID).delete()
                nodes.delete()
                builds = BuildInfo.objects.filter(buildID__startswith=single_id)
                for build in builds:
                    res = self.del_build(build_id=build.buildID)
                builds.delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1305,"data":"ERROR: Delete block error"}
        return {"code":1205,"data":"ERROR: Delete block successfully"}
    # 删除楼栋
    def del_build(self,build_id):
        try:
            with transaction.atomic():
                BuildInfo.objects.filter(buildID=build_id).delete()
                FloorInfo.objects.filter(buildID=build_id).delete()
                ModuleInfo.objects.filter(moduleID__startswith=build_id).delete()
                schedules = ScheduleInfo.objects.filter(scheduleID__startswith=build_id)
                for sch in schedules:
                    ImageInfo.objects.filter(mapID=sch.scheduleID).delete()
                schedules.delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":13061,"data":"ERROR: Delete build {} error".format(build_id)}
        return {"code":1206,"data":"SECCESS: Delete build {} success".format(build_id)}
    # 删除节点
    def del_node(self,node_id):
        try:
            with transaction.atomic():
                NodeInfo.objects.filter(nodeID=node_id).delete()
                ImageInfo.objects.filter(mapID=node_id).delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1307,"data":"ERROR: Delete node {} error".format(node_id)}
        return {"code":1207,"data":"ERROR: Delete node {} ok".format(node_id)}
    # 假删除大事件/形象进度
    def change_finish_state(self,ID,mode):
        try:
            if mode.lower()=='node':
                data = NodeInfo.objects.get(nodeID=ID)
            elif mode.lower()=='schedule':
                data = ScheduleInfo.objects.get(scheduleID=ID)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1303,"data":"ERROR: Get data from db error"}
        try:
            data.finishState= 0
            data.finishTime = None
            data.save()
            if mode.lower()=='node':
                project = ProjectInfo.objects.get(projectID=ID//10)
                if data.nodeName=='中标通知书时间':
                    project.awarDate = None
                elif data.nodeName=='开工令时间':
                    project.commDate = None
                elif data.nodeName=='施工许可证时间':
                    project.permitDate = None
                    project.state='prepare'
                elif data.nodeName=='竣工顺延日期':
                    project.continueDate = None
                project.save()
            ImageInfo.objects.filter(mapID=ID).delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1311,"data":"ERROR: Delete {} {} error".format(mode,ID)}
        return {"code":1210,"data":"SECCESS: Delete {} {} success".format(mode,ID)}

# 首页
class Index(View):
    def __init__(self):
        self._department_names = ['管理层','生产部','安全部','技术部','商务部','党群部']
        self.count = len(self._department_names)
    # 新增部门信息
    def add_frame(self,project_id):
        for i in range(self.count):
            departmentID=project_id *100+10+i
            try:
                if i==0:
                    leader = '项目经理'
                    staff = '秘书'
                    standard = 5
                else:
                    leader = self._department_names[i]+'部长'
                    staff = self._department_names[i]+'员工'
                    standard = 10
                with transaction.atomic():
                    curren_step = 'dep'
                    DepartmentInfo.objects.create(
                        departmentID=departmentID,
                        departmentName=self._department_names[i],
                        projectID=project_id,
                        standard=standard
                    )
                    curren_step = 'pos for leader'
                    PositionInfo.objects.create(
                        positionID=departmentID*100+10,
                        positionName=leader
                    )
                    curren_step = 'pos for normal'
                    PositionInfo.objects.create(
                        positionID=departmentID*100+11,
                        positionName=staff
                    )
            except:
                log_tools.log_error(traceback.format_exc())
                return {"code":1320,"data":"[FUN ERROR] Add new position error in {}".format(curren_step)}
        return {"code":1103,"data":"add framework success"}

    # 获取项目列表
    def get(self,request):
        try:
            token = request.GET.get('token','')
            state = request.GET.get('module','prepare')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not state:
            log_tools.log_param_error('获取项目列表',[token,state])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取项目列表时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取项目列表',request.GET)
        user = UserInfo.objects.get(No=user_info['userid'])
        if user.departmentID==999999:
            mapping_projects = ProjectInfo.objects.all()
        try:
            mapping_projects = RelationInfo.objects.filter(userID=user_info['userid'])
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        data = []
        if state=='all':
            project_name = request.GET.get('projectName','')
            try:
                ProjectInfo.objects.get(projectName=project_name)
            except:
                res = {"code":1303,"data":1}
            else:
                res = {"code":1303,"data":0}
            finally:
                log_tools.log_response(res)
                return JsonResponse(res)
        for project in mapping_projects:
            project = ProjectInfo.objects.get(projectID=project.projectID)
            if project.state==state and not project.deleted:
                image =  ImageInfo.objects.filter(mapID=project.projectID).first()
                data.append({
                    "pId":project.projectID,
                    "pName":project.projectName,
                    "pIcon":image.imgPath
                    })
        res = {"code":1003,"data":data}
        log_tools.log_response(res)
        return JsonResponse(res)
    
    # 新增项目
    def post(self,request):
        try:
            param = json.loads(request.body)
            token=param.get('token','')
            projectName=param.get('projectName','')
            projectImgs=param.get('projectImgs',[])
            projectFormats=param.get('projectFormats','')
            barea=float(param.get('barea',0.0))
            carea=float(param.get('carea',0.0))
            amount=float(param.get('amount',0.0))
            duration=int(param.get('duration',0))
            conUnit=param.get('conUnit',{})
            supUnit=param.get('supUnit',{})
            advUnit=param.get('advUnit',{})
            surUnit=param.get('surUnit',{})
            desUnit=param.get('desUnit',{})
            project_manager = param.get('projectManager','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not projectName or not projectImgs or not projectFormats or not barea or not carea \
            or not amount or not duration or not conUnit or not supUnit or not advUnit or not surUnit or not desUnit or not project_manager:
            log_tools.log_param_error('新增项目',[token,projectName,projectImgs,projectFormats,barea,carea,amount,duration,conUnit,supUnit,advUnit,surUnit,desUnit,project_manager])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('新增项目时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'新增项目',param)
        right = get_right(user_info)
        projects = ProjectInfo.objects.filter(projectName=projectName)
        if projects.count()!=0 and not projects.first().deleted:
            log_tools.log_error('新增项目时重名')
            return JsonResponse({"code":1319,"data":"[FUN ERROR] Add new project info error,project has existed"})
        try:
            project_manager = int(project_manager)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"[FUN ERROR] Args error"})
        try:
            now_max = get_max_id('project',ProjectInfo.objects.all())
            project_id = now_max+1 if now_max!=0 else 1000
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        # 项目概况      
        try:
            with transaction.atomic():
                # 基础信息
                temp = ProjectInfo.objects.create(
                    projectID=project_id,
                    projectName=projectName,
                    projectFormats=projectFormats,
                    barea=barea,carea=carea,amount=amount,duration=duration,
                    conUnit=project_id*10,
                    supUnit=project_id*10+1,
                    advUnit=project_id*10+2,
                    surUnit=project_id*10+3,
                    desUnit=project_id*10+4,
                    state='prepare',deleted=0,
                    projectManager=project_manager
                )
                # 默认通知
                NoticeInfo.objects.create(noticeID=project_id*100+1,noticeMsg='暂无通知',projectID=project_id)
                # 施工单位
                units = [conUnit,supUnit,advUnit,surUnit,desUnit]
                for index in range(len(units)):
                    unit = units[index]
                    UnitsInfo.objects.create(
                        unitsID=project_id*10+index,
                        unitsName=unit['name'],
                        contect=unit['contact'],
                        tel=unit['tel']
                    ) 
                # 项目图片
                now_max = get_max_id('img',ImageInfo.objects.all())
                img_id = now_max+1 if now_max!=0 else 100000
                for i in range(len(projectImgs)):
                    temp = ImageInfo.objects.create(
                        imgID=img_id+i,
                        imgPath=projectImgs[i],
                        mapID=project_id,
                    )
                # 项目经理
                departmentID = project_id *100+10+0
                positionID = departmentID*100+10
                person = UserInfo.objects.get(No=project_manager)
                person.departmentID = departmentID
                person.positionID = positionID
                person.rightLevel = 2
                person.save()
                relation = RelationInfo.objects.filter(relationID=project_manager*10000+project_id)
                if not relation:
                    RelationInfo.objects.create(
                        relationID=project_manager*10000+project_id,
                        userID=project_manager,
                        projectID=project_id
                    )
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1319,"data":"[FUN ERROR] Add new project info error"})
        # 工期相关节点
        nodes = ['合同开工时间','合同竣工时间','中标通知书时间','开工令时间','施工许可证时间','工期顺延时间']
        for i in range(len(nodes)):
            NodeInfo.objects.create(
                nodeID=project_id*10+i,
                nodeName=nodes[i],
                uploadPeople=project_manager,
                deadline=19000101,
                finishState=0,
                phaseID=project_id,
                right=right
            )
        # 项目经理人员项目关联
        try:
            try:
                _ = RelationInfo.objects.get(userID=project_manager,projectID=project_id)
            except:
                temp = RelationInfo.objects.create(
                    relationID=project_manager*10000+project_id,
                    userID=project_manager,
                    projectID=project_id
                )
                temp.save()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1321,"data":"[FUN ERROR] Modify manager relation error"}
        # 组织架构 - 部门
        res = self.add_frame(project_id)
        if res['code']<1200:
            res = {"code":1103,"data":"add project success"}
        log_tools.log_response(res)
        return JsonResponse(res)

# 项目概况
class Survey(View):
    # 获取项目概况
    def get(self,request):
        try:
            token = request.GET.get('token','')
            projectID = int(request.GET.get("projectId",""))
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not projectID or not token:
            log_tools.log_param_error('获取项目概况',[projectID,token])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            projectID=int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取项目概况时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取项目概况',request.GET)
        try:
            project = ProjectInfo.objects.get(projectID=projectID)
            conUnit = UnitsInfo.objects.get(unitsID=project.conUnit)
            supUnit = UnitsInfo.objects.get(unitsID=project.supUnit)
            advUnit = UnitsInfo.objects.get(unitsID=project.advUnit)
            surUnit = UnitsInfo.objects.get(unitsID=project.surUnit)
            desUnit = UnitsInfo.objects.get(unitsID=project.desUnit)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        res = {
            "code":1016,
            "data":{
                "projectName":project.projectName,
                "baseInfo":{
                    "projectFormats":project.projectFormats,
                    "conCommDate":get_date(project.conCommDate),
                    "conCompDate":get_date(project.conCompDate),
                    "awarDate":get_date(project.awarDate),
                    "commDate":get_date(project.commDate),
                    "permitDate":get_date(project.permitDate),
                    "continueDate":get_date(project.continueDate),
                    "barea":project.barea,
                    "carea":project.carea,
                    "amount":project.amount,
                    "duration":project.duration,
                },
                "pcharge":[
                    {
                        "imgPath":"",
                        "title":"conUnit",
                        "id":project.conUnit,
                        "name":conUnit.unitsName,
                        "contact":conUnit.contect,
                        "phone":conUnit.tel
                    },
                    {
                        "imgPath":"",
                        "title":"supUnit",
                        "id":project.supUnit,
                        "name":supUnit.unitsName,
                        "contact":supUnit.contect,
                        "phone":supUnit.tel
                    },
                    {
                        "imgPath":"",
                        "title":"advUnit",
                        "id":project.advUnit,
                        "name":advUnit.unitsName,
                        "contact":advUnit.contect,
                        "phone":advUnit.tel
                    },
                    {
                        "imgPath":"",
                        "title":"surUnit",
                        "id":project.surUnit,
                        "name":surUnit.unitsName,
                        "contact":surUnit.contect,
                        "phone":surUnit.tel
                    },
                    {
                        "imgPath":"",
                        "title":"desUnit",
                        "id":project.desUnit,
                        "name":desUnit.unitsName,
                        "contact":desUnit.contect,
                        "phone":desUnit.tel
                    },
                ]
            }
        }
        log_tools.log_response(res)
        return JsonResponse(res)

    # 修改项目概况
    def post(self,request):
        try:
            param = json.loads(request.body)
            token=param.get('token','')
            projectID=param.get('projectID','')
            editField=param.get('editField','')
            editRes=param.get('editRes','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not projectID or not editField or not editRes or not token:
            log_tools.log_param_error('修改项目概况',[token,projectID,editField,editRes])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('修改项目概况时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            projectID=int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        log_tools.log_request(user_info['username'],'修改项目概况',param)
        if editField in ('name','contact','phone'):
            try:
                unit_id,value = int(editRes[0]),editRes[1]
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                unit = UnitsInfo.objects.get(unitsID=unit_id)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            if editField=='name':
                unit.unitsName = value
            elif editField=='contact':
                unit.contect = value
            elif editField=='phone':
                unit.tel = value
            try:
                unit.save()
            except:
                log_tools.log_error(traceback.format_exc())
                res = {"code":1317,"data":"Modify project info error"}
            else:
                res = {"code":1203,"data":'modify project info ok'}
            finally:
                log_tools.log_response(res)
                return JsonResponse(res)
        else:
            try:
                project = ProjectInfo.objects.get(projectID=projectID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            if 'Date' in editField:
                dates = editRes.split('-')
                month = dates[1]
                day = dates[2]
                if len(month)==1:
                    month = '0'+month
                if len(day)==1:
                    day = '0'+ day
                editRes = dates[0]+month+day
                editRes = int(editRes)
            if editField=="projectName":
                project.projectName = editRes
            elif editField=="projectFormats":
                project.projectFormats = editRes
            elif editField=='barea':
                project.barea = editRes
            elif editField=='carea':
                project.carea = editRes
            elif editField=='amount':
                project.amount = editRes
            elif editField=='duration':
                project.duration = editRes
            elif editField=='conCommDate':
                project.conCommDate = editRes
            elif editField=='conCompDate':
                project.conCompDate = editRes
            else:
                res = {"code":1301,"data":"ERROR: Args error"}
                log_tools.log_response(res)
                return JsonResponse(res)
            try:
                project.save()
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1317,"data":"Modify project info error"})
            res = {"code":1203,"data":'modify project info ok'}
            log_tools.log_response(res)
            return JsonResponse(res)

# 组织架构
class Framework(View):
    # 获取组织架构
    def get(self,request):
        try:
            token = request.GET.get('token','')
            projectID = request.GET.get("projectId","")
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not projectID or not token:
            log_tools.log_param_error('获取组织架构',[token,projectID])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            projectID = int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取组织架构时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取组织架构',request.GET)
        try:
            deps = DepartmentInfo.objects.filter(projectID=projectID)
            project = ProjectInfo.objects.get(projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        projectManager = {"name":"","wid":""}
        departmentList = []
        sub_department = {}
        projectManager["name"] = ''
        projectManager["wid"] = ''
        manager = project.projectManager
        if manager:
            manager = UserInfo.objects.get(No=manager)
            projectManager["name"] = manager.userName
            projectManager["wid"] = manager.No

        for dep in deps:
            if dep.departmentID==999999 or dep.departmentName in ['管理层','工程部','未指定']:
                continue
            try:
                positions = PositionInfo.objects.filter(positionID__startswith=dep.departmentID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            standard = dep.standard
            users_now = UserInfo.objects.filter(departmentID=dep.departmentID).count()
            if users_now>standard:
                dep.standard = users_now
                dep.save()
            dep_info = {"did":dep.departmentID,"departmentName":"","divisionManager": "","wid": "","subordinate":[],"sid":[],'standard':dep.standard}
            dep_info["departmentName"] = dep.departmentName
            for pos in positions:
                if pos.positionID%100==10:
                    try:
                        manager = UserInfo.objects.get(positionID=pos.positionID)
                    except:
                        continue
                    else:
                        dep_info["divisionManager"] = manager.userName
                        dep_info["wid"] = manager.No
                else:
                    try:
                        users = UserInfo.objects.filter(positionID=pos.positionID)
                    except:
                        log_tools.log_error(traceback.format_exc())
                        return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                    for user in users:
                        if user.userName not in dep_info["subordinate"]:
                            dep_info["subordinate"].append(user.userName)
                            dep_info["sid"].append(user.No)
            if dep.departmentID%100<20:
                departmentList.append(dep_info)
                sub_department[dep.departmentID] = ''
            else:
                sub_department[dep.departmentID-10] = dep_info        
        res = {
            "code":1017,
            "data":{
                "projectName":project.projectName,
                "projectManager":projectManager,
                "departmentList":departmentList,
                "sub_department":sub_department
            }
        }
        log_tools.log_response(res)
        return JsonResponse(res)

    # 修改组织架构
    def post(self,request):
        try:
            param = json.loads(request.body)
            token=param.get('token','')
            oldId=param.get('oldId','')
            newId=param.get('newId','')
            mode=param.get('mode','0')
            projectId = param.get('projectId','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not oldId or not newId or not projectId:
            log_tools.log_param_error('修改组织架构',[token,oldId,newId,projectId])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('修改组织架构时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            projectId = int(projectId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        # 修改标配人数
        if 'standard' in str(oldId):
            log_tools.log_request(user_info['username'],'修改标配人数',param)
            newId = int(newId)
            try:
                dep_id = oldId.split('standard')[1]
                dep = DepartmentInfo.objects.get(departmentID=dep_id)
                dep.standard = newId
                dep.save()
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1323,"data":{"state":'error','msg':"修改标配人数失败"}})
            res = {"code":1201,"data":{"state":'success','msg':"修改标配人数成功"}}
            log_tools.log_response(res)
            return JsonResponse(res)
        # 删除员工/部门经理
        elif str(oldId)=='delete':
            log_tools.log_request(user_info['username'],'删除员工/部门经理',param)
            try:
                with transaction.atomic():
                    user = UserInfo.objects.get(No=newId)
                    reset_user(user)
                    relation = RelationInfo.objects.get(userID=newId,projectID=projectId)
                    relation.delete()
            except:
                log_tools.log_error(traceback.format_exc())
                res = {"code":1302,"data":{"state":'error','msg':"删除失败"}}
            else:
                res = {"code":1302,"data":{"state":'success','msg':"删除成功"}}
            finally:
                log_tools.log_response(res)
                return JsonResponse(res)
        else:
            flag = 'add'
            try:
                int(oldId)
            except:
                flag='add'
            else:
                flag='modify'
        # 新增员工/部门经理
        if flag=='add':
            newId = int(newId)
            department_name = oldId
            user = UserInfo.objects.get(No=newId)
            if int(user.departmentID)%100==10:
                res = {"code":1302,"data":{"state":'error','msg':"不能为项目经理!"}}
                log_tools.log_response(res)
                return JsonResponse(res)
            try:
                department = DepartmentInfo.objects.get(projectID=projectId,departmentName=department_name)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":{"state":'error','msg':"新增失败"}})
            standard = department.standard
            users_now = UserInfo.objects.filter(departmentID=department.departmentID).count()
            if users_now>=standard:
                res = {"code":1302,"data":{"state":'error','msg':"人员超出限制!"}}
                log_tools.log_response(res)
                return JsonResponse(res)
            user.departmentID = department.departmentID
            if int(mode)==0:
                log_tools.log_request(user_info['username'],'新增部员',param)
                user.positionID = int(department.departmentID)*100+11
                user.rightLevel = 0
            else:
                log_tools.log_request(user_info['username'],'新增部门经理',param)
                user.positionID = int(department.departmentID)*100+10
                user.rightLevel = 1
            user.save()

            try:
                relation = RelationInfo.objects.get(userID=user.No)
            except:
                log_tools.log_request(user_info['username'],'新员工，无项目',param)
                RelationInfo.objects.create(
                    userID=user.No,
                    projectID=projectId,
                    relationID = user.No*10000+projectId
                )
            else:
                if relation.projectID!=projectId:
                    log_tools.log_request(user_info['username'],'旧员工，其他项目',param)
                    relation.delete()
                    RelationInfo.objects.create(
                        userID=user.No,
                        projectID=projectId,
                        relationID = user.No*10000+projectId
                    )
            res = {"code":1201,"data":{"state":'success','msg':"添加成功"}}
            log_tools.log_response(res)
            return JsonResponse(res)        
        # 修改员工/部门经理/项目经理
        elif flag=='modify':
            new_user =UserInfo.objects.get(No=newId)
            # 修改项目经理
            if int(mode)==1:
                log_tools.log_request(user_info['username'],'修改项目经理',param)
                try:
                    with transaction.atomic():
                        project = ProjectInfo.objects.get(projectID=projectId)
                        project.projectManager = newId
                        project.save()
                        old_user = UserInfo.objects.get(No=oldId)
                        try:
                            old_relation = RelationInfo.objects.get(relationID=int(old_user.No)*10000+projectId)
                        except:
                            print('已无关系')
                        else:
                            print('删除关系')
                            old_relation.delete()
                        # 如果b不是项目经理,有其他职位
                        if int(new_user.departmentID)%100>10:
                            try:
                                new_user_old_relation = RelationInfo.objects.get(userID=newId)
                            except:
                                print('没有关联项目')
                                RelationInfo.objects.create(
                                    userID=newId,
                                    projectID=projectId,
                                    relationID = int(newId)*10000+projectId
                                )
                            else:
                                if new_user_old_relation.projectID!=projectId:
                                    print('有关联项目但不是该项目')
                                    new_user_old_relation.delete()
                                    RelationInfo.objects.create(
                                        userID=newId,
                                        projectID=projectId,
                                        relationID = int(newId)*10000+projectId
                                    )
                        elif int(new_user.departmentID)%100==10:
                            try:
                                new_user_old_relation = RelationInfo.objects.get(relationID = int(newId)*10000+projectId)
                            except:
                                print('是项目经理但未关联该项目')
                                RelationInfo.objects.create(
                                    userID=newId,
                                    projectID=projectId,
                                    relationID = int(newId)*10000+projectId
                                )
                        new_user.departmentID = old_user.departmentID
                        new_user.positionID = old_user.positionID
                        new_user.rightLevel = old_user.rightLevel
                        new_user.save()
                except:
                    res = {"code":1302,"data":{"state":'error','msg':"修改失败!"}}
                    log_tools.log_response(res)
                    return JsonResponse(res)
                old_user_manage_project = ProjectInfo.objects.filter(projectManager=oldId)
                if old_user_manage_project.count()==0:
                    reset_user(old_user)
                res = {"code":1302,"data":{"state":'success','msg':"修改成功!"}}
                log_tools.log_response(res)
                return JsonResponse(res)
            # 修改其他人员
            else:
                log_tools.log_request(user_info['username'],'修改其他人员',param)
                if int(new_user.departmentID)%100==10:
                    res = {"code":1302,"data":{"state":'error','msg':"修改失败!该员工为项目经理"}}
                    log_tools.log_response(res)
                    return JsonResponse(res)
                try:
                    with transaction.atomic():
                        old_user = UserInfo.objects.get(No=oldId)
                        new_user.departmentID = old_user.departmentID
                        new_user.positionID = old_user.positionID
                        new_user.rightLevel = old_user.rightLevel
                        old_relation = RelationInfo.objects.get(relationID=int(old_user.No)*10000+projectId)
                        old_relation.delete()
                        new_user.save()
                        reset_user(old_user)
                except:
                    res = {"code":1302,"data":{"state":'error','msg':"修改失败!"}}
                    log_tools.log_response(res)
                    return JsonResponse(res)
                try:
                    new_user_old_relation = RelationInfo.objects.get(userID=newId)
                except:
                    RelationInfo.objects.create(
                        userID=newId,
                        projectID=projectId,
                        relationID = int(newId)*10000+projectId
                    )
                else:
                    if new_user_old_relation.projectID!=projectId:
                        new_user_old_relation.delete()
                        RelationInfo.objects.create(
                            userID=newId,
                            projectID=projectId,
                            relationID = int(newId)*10000+projectId
                        )
                res = {"code":1302,"data":{"state":'success','msg':"修改成功"}}
                log_tools.log_response(res)
                return JsonResponse(res)

# 组织架构部门修改
class ModifyDepartments(View):
    def post(self,request):
        try:
            param = json.loads(request.body)
            token=param.get('token','')
            departmentID=param.get('departmentID','')
            mode=param.get('mode','addDep')
            name=param.get('name','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not departmentID or not token or not name:
            log_tools.log_param_error('组织架构部门修改',[token,departmentID,name])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            departmentID = int(departmentID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('组织架构部门修改时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        if mode=='addDep':
            log_tools.log_request(user_info['username'],'新增部门',param)
            try:
                with transaction.atomic():
                    DepartmentInfo.objects.create(
                        departmentID=departmentID+10,
                        departmentName = name,
                        projectID = departmentID//100,
                        standard = 10
                    )
                    PositionInfo.objects.create(
                        positionID=(departmentID+10)*100+10,
                        positionName=name+'部门经理'
                    )
                    PositionInfo.objects.create(
                        positionID=(departmentID+10)*100+11,
                        positionName=name+'员工'
                    )
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1350,"data":"ERROR: Add new department error"})
            res = {"code":1110,"data":"Add new department successfully"}
            log_tools.log_response(res)
            return JsonResponse(res)
        elif mode=='changeDep':
            log_tools.log_request(user_info['username'],'修改部门名称',param)
            try:
                with transaction.atomic():
                    department = DepartmentInfo.objects.get(departmentID=departmentID)
                    department.departmentName = name
                    department.save()
                    manager = PositionInfo.objects.get(positionID=departmentID*100+10)
                    staff = PositionInfo.objects.get(positionID=departmentID*100+11)
                    manager.positionName = name+'部门经理'
                    staff.positionName = name+'员工'
                    manager.save()
                    staff.save()
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1351,"data":"ERROR: Modify department name error"})
            res = {"code":1021,"data":"Modify department name successfully"}
            log_tools.log_response(res)
            return JsonResponse(res)

# 单体信息
class SingleModel(View):
    def __init__(self):
        # 主体,砌体,抹灰,水电,消防,暖通,外立面,门窗,装修
        self._progress = {
            1:['mainPrograss',4],
            2:['brickwork',4],
            3:['plasterer','all'],
            4:['waterElec','all'],
            5:['fireControl','all'],
            6:['HVACsystem','all'],
            7:['externalWall',2],
            8:['doorWindows','all'],
            9:['fitment',4]
        }
        self._buttlin = {
            'mainPrograss':[
                '架体搭设完成',
                '钢筋绑扎完成',
                '模板安装完成',
                '混凝土浇筑完成',
            ],
            'brickwork':[
                '植筋完成',
                '反坎完成',
                '砌筑完成',
                '抹灰完成',
            ],
            'plasterer':[
                '给水管完成',
                '排水管完成',
                '空调水管完成',
                '水表完成',
            ],
            'waterElec':[
                '强电完成',
                '弱电完成',
            ],
            'fireControl':[
                '消防水完成',
                '消防电完成',
                '烟感完成',
                '应急照明完成',
                '末端完成',
            ],
            'HVACsystem':[
                '新风完成',
                '排风完成',
            ],
            'externalWall':[
                '基层完成',
                '面层完成'
            ],
            'doorWindows':[
                '门框完成',
                '门扇完成',
                '窗框完成',
                '固定玻璃完成',
                '开启扇完成',
            ],
            'fitment':[
                '墙面完成',
                '天面完成',
                '地面完成',
                '移交完成'
            ]
        }
        self.count = len(self._progress)
        self._phaseNameDict = {1:'prepare',2:"onBuild",3:"accept"}
        self._defult_node = {
            # 添加项目时候添加
            'baseInfo':[
                '合同开工时间',
                '合同竣工时间',
                '中标通知书时间',
                '开工令时间',
                '施工许可证时间',
                '工期顺延时间',
            ],
            # 添加楼栋时候添加
            'prepare':[
                '场地移交',
                '围挡封闭',
                '三通一平',
                '临水临电接驳',
                '办公生活区临设完成',
                '工友村临设完成',
                '正式开工',
            ],
            'onBuild':[
                '基坑支护完成',
                '土方开挖完成',
                '底板浇筑完成',
                '地下室封顶',
                '主体结构封顶',
                '屋面构筑完成',
                '二次结构完成',
                '外架/模架拆除完成',
                '电梯拆除完成',
                '塔吊拆除完成',
                '正式电梯移交',
                '外立面完成',
                '装饰装修完成',
                '正式供水',
                '正式供电',
                '园林绿化完成',
            ],
            'accept':[
                '地基与基础验收',
                '主体结构验收',
                '建筑装饰装修验收',
                '建筑屋面验收',
                '建筑给水排水及采暖验收',
                '建筑电气验收',
                '智能建筑验收',
                '通风与空调验收',
                '电梯验收',
                '建筑节能工程验收',
                '防雷验收',
                '人防验收',
                '水土保持验收',
                '燃气验收',
                '规划验收',
                '环评验收',
                '档案馆验收',
                '竣工初验',
                '消防验收',
                '竣工验收',
                '竣工备案',
            ]
        }
    # 新增标段
    def add_segment(self,param):
        try:
            projectID=param.get('projectId',"")
            segment=param.get('segment','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not projectID or not segment:
            log_tools.log_param_error('新增标段',[projectID,segment])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            projectID = int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        try:
            segments = SegmentInfo.objects.filter(projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        now_max = get_max_id('seg',segments)
        segmentId= now_max+1 if now_max!=0 else projectID*100+10
        try:
            SegmentInfo.objects.create(
                segmentID=segmentId,
                segmentName=segment,
                projectID=projectID
            )
        except:
            resp = {"code":1326,"data":"Add segment error"}
        else:
            resp = {'code':1104,'data':'add segment success'}
        return resp
    # 新增地块
    def add_block(self,param):
        try:
            segmentId=param.get('segmentId',"")
            block=param.get('block','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not segmentId or not block:
            log_tools.log_param_error('新增地块',[segmentId,block])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            segmentId = int(segmentId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        try:
            blocks = BlockInfo.objects.filter(segmentID=segmentId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        now_max = get_max_id('block',blocks)
        blockId= now_max+1 if now_max!=0 else segmentId*100+10
        try:
            BlockInfo.objects.create(blockID=blockId,blockName=block,segmentID=segmentId)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1327,"data":"Add block error"}
        else:
            return {'code':1105,'data':'add block success'}
    # 新增单体
    def add_single(self,param,respID,right):
        try:
            blockId=param.get('blockId',"")
            single=param.get('single','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not blockId or not single:
            log_tools.log_param_error('新增单体',[blockId,single])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            blockId = int(blockId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        try:
            singles = SingleInfo.objects.filter(blockID=blockId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        now_max = get_max_id('single',singles)
        singleId= now_max+1 if now_max!=0 else blockId*100+10
        try:
            SingleInfo.objects.create(singleID=singleId,singleName=single,blockID=blockId)
            for i in range(1,4):
                phaseId = singleId*10+i
                PhaseInfo.objects.create(phaseID=phaseId,phaseName=self._phaseNameDict[i],singleID=singleId)
                nodes = self._defult_node[self._phaseNameDict[i]]
                nodeId = phaseId*100+11
                for node in nodes:
                    NodeInfo.objects.create(
                        nodeID=nodeId,
                        nodeName=node,
                        uploadPeople=respID,
                        deadline=int(datetime.date.today().strftime('%Y%m%d')),
                        finishState=0,
                        phaseID=phaseId,
                        right=right
                    )
                    nodeId+=1
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1328,"data":"Add single error"}
        else:
            return {'code':1106,'data':'add single success'}
    # 新增楼栋
    def add_build(self,param):
        try:
            token = param.get('token',"")
            singleId = param.get('singleId',"")
            floorMin = param.get('floorMin',"")
            floorMax = param.get('floorMax',"") 
            build =param.get('build',"")
            respID = param.get('respID',"")
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1301,"data":"ERROR: Args error"}
        if not token or not singleId or not str(floorMin) or not str(floorMax) or not build or not respID:
            return {"code":1301,"data":"ERROR: Args error"}
        try:
            singleId = int(singleId)
            try:
                floorMin = int(floorMin)
                floorMax = int(floorMax)+1
                mode='number'
            except:
                floorMin = ord(floorMin.lower())-ord('a')
                floorMax = ord(floorMax.lower())-ord('a')+1+1
                mode='alpha'
            respID = int(respID)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1302,"data":"ERROR: Args type error"}
        try:
            builds = BuildInfo.objects.filter(singleID=singleId)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1303,"data":"[FUN ERROR] Get data from db error"}
        now_max = get_max_id('builds',builds)
        buildId = now_max+1 if now_max!=0 else singleId*100+10
        projectID = singleId//1000000
        try:
            relation = RelationInfo.objects.filter(relationID=respID*10000+projectID).count()
            # 添加楼栋信息
            with transaction.atomic():
                BuildInfo.objects.create(buildID=buildId,buildName=build,respID=respID,singleID=singleId)
                # 添加负责人和项目关联信息
                if not relation:
                    RelationInfo.objects.create(relationID=respID*10000+projectID,userID=respID,projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1330,"data":"Add build error"}
        # 添加楼层信息
        return self.add_floor(buildId,floorMin,floorMax,respID,mode)

    # 新增楼层
    def add_floor(self,buildId,floorMin,floorMax,respID,mode='number'):
        try:
            with transaction.atomic():
                for i in range(floorMin,floorMax-1):
                    if mode=='alpha':
                        floorID = buildId*1000+300+abs(i)
                    elif mode=='number':
                        if i==0:
                            continue
                        elif i<0:
                            floorID = buildId*1000+200+abs(i)
                        else:
                            floorID = buildId*1000+100+abs(i)
                    FloorInfo.objects.create(
                        floorID=floorID,
                        floorNum=i,
                        buildID=buildId,
                    )
                    # 添加模块信息
                    for p in range(self.count):
                        p=p+1
                        moduleID = floorID*100+p
                        module_name = self._progress[p][0]
                        if self._progress[p][1]=='all':
                            finish_tag = 'all'
                        else:
                            finish_tag = moduleID*10+self._progress[p][1]
                        schedule_count = len(self._buttlin[module_name])
                        ModuleInfo.objects.create(
                            moduleID=moduleID,
                            moduleName=module_name,
                            floorID=floorID,
                            finishCount=0,
                            total=schedule_count,
                            finishiTag=finish_tag
                        )
                        # 添加简报信息
                        for q in range(schedule_count):
                            ScheduleInfo.objects.create(
                                scheduleID=moduleID*10+q+1,
                                scheduleName=self._buttlin[module_name][q],
                                moduleID=moduleID,
                                uploadPeople=respID,
                                finishState=0
                            )
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1329,"data":"Add floor error"}
        return {'code':1107,'data':'add build success'}

    # 删除楼层
    def delete_floor(self,buildId,floorMin,floorMax,mode='number'):
        try:
            with transaction.atomic():
                for i in range(floorMin,floorMax-1):
                    if mode=='alpha':
                        floorID = buildId*1000+300+abs(i)
                    elif mode=='number':
                        if i==0:
                            continue
                        elif i<0:
                            floorID = buildId*1000+200+abs(i)
                        else:
                            floorID = buildId*1000+100+abs(i)
                    FloorInfo.objects.filter(floorID=floorID).delete()
                    modules = ModuleInfo.objects.filter(floorID=floorID)
                    for module in modules:
                        ScheduleInfo.objects.filter(moduleID=module.moduleID).delete()
                    modules.delete()
        except:
            log_tools.log_error(traceback.format_exc())
            return {"code":1331,"data":"Delete floor error"}
        return {'code':1203,'data':'delete floor success'}

    # 获取单体信息
    def get(self,request):
        try:
            token = request.GET.get('token','')
            blockID = request.GET.get("blockId","")
            projectID = request.GET.get("projectId","")
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not blockID or not projectID or not token:
            log_tools.log_param_error('获取单体信息',[token,blockID,projectID])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            blockID = int(blockID)
            projectID = int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取单体信息')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取单体信息',request.GET)
        try:
            singles = SingleInfo.objects.filter(blockID=blockID)
            project = ProjectInfo.objects.get(projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        data = {"projectName":project.projectName,"single":[]}
        for single in singles:
            single_info = {
                "singleId":single.singleID,
                "name":single.singleName,
                "singleMsg":[]
            }
            try:
                builds = BuildInfo.objects.filter(singleID=single.singleID)
                for build in builds:
                    build_info = {
                        "buildingID":build.buildID,
                        "building":build.buildName,
                        "floor":"",
                        "buildingOwner":UserInfo.objects.get(No=build.respID).userName,
                    }
                    floors = FloorInfo.objects.filter(buildID=build.buildID)
                    floor_min,floor_max = -1000,1000
                    fmin,fmax = '',''
                    for floor in floors:
                        if floor_min<-999:
                            floor_min = floor.floorNum
                            fmin = floor.floorID
                        if floor_max>999:
                            floor_max = floor.floorNum
                            fmax = floor.floorID
                        if floor.floorNum<floor_min:
                            floor_min = floor.floorNum
                            fmin = floor.floorID
                        if floor.floorNum>floor_max:
                            floor_max = floor.floorNum
                            fmax = floor.floorID
                    if fmin%1000>=300:
                        floor_min = chr(fmin%100+ord('a'))
                        floor_max = chr(fmax%100+ord('a'))
                    build_info["floor"] = "{}~{}".format(floor_min,floor_max)
                    single_info["singleMsg"].append(build_info)
                data["single"].append(single_info)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        res = {'code':1018,'data':data}
        log_tools.log_response(res)
        return JsonResponse(res)

    # 新增/修改单体信息
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            option = param.get('option','add')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not option:
            log_tools.log_param_error('新增大事件',[token,option])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('新增/修改单体信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        right = get_right(user_info)
        if option=='add':
            mode  = param.get('mode','segment')
            # 新增标段
            if mode == 'segment':
                log_tools.log_request(user_info['username'],'新增标段',param)
                res = self.add_segment(param)
            # 新增地块
            elif mode =="block":
                log_tools.log_request(user_info['username'],'新增地块',param)
                res = self.add_block(param)
            # 新增单体
            elif mode =="single":
                log_tools.log_request(user_info['username'],'新增单体',param)
                res = self.add_single(param,user_info['userid'],right)
                # user_info['userid']
            # 新增楼栋
            elif mode =="build":
                log_tools.log_request(user_info['username'],'新增楼栋',param)
                res = self.add_build(param)
            else:
                res = {"code":1324,"data":"unknow mode"}
            log_tools.log_response(res)
            return JsonResponse(res)

        elif option=='modify':
            try:
                buildID=param.get('buildId',"")
                editField=param.get('editField',"")
                editRes=param.get('editRes',"")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not buildID or not editField or not editRes:
                log_tools.log_param_error('修改单体信息',[buildID,editField,editRes])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                build = BuildInfo.objects.get(buildID=buildID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1306,"data":"[FUN ERROR] Get data from db error"})
            if editField=='buildName':
                log_tools.log_request(user_info['username'],'修改楼栋名称',param)
                try:
                    build.buildName = editRes
                    build.save()
                except:
                    log_tools.log_error(traceback.format_exc())
                    return {"code":1325,"data":"Modify build error"}
            elif editField=='respID':
                log_tools.log_request(user_info['username'],'修改楼栋负责人',param)
                editRes=param.get('editRes',"")
                if not editRes:
                    log_tools.log_param_error('修改楼栋负责人',[buildID,editField,editRes])
                    return JsonResponse({"code":1301,"data":"ERROR: Args error"})
                try:
                    build.respID = int(editRes)
                    build.save()
                except:
                    log_tools.log_error(traceback.format_exc())
                    return {"code":1325,"data":"Modify build error"}
                else:
                    res = {'code':1202,'data':'Modify build successfully'}
            elif editField=='add':
                log_tools.log_request(user_info['username'],'增加楼层',param)
                for floor_range in editRes:
                    try:
                        floorMin,floorMax = int(floor_range[0]),int(floor_range[1])+1
                        mode = 'number'
                    except:
                        floorMin,floorMax = ord(floor_range[0].lower())-ord('a'),ord(floor_range[1].lower())-ord('a')+1
                        mode = 'alpha'
                    respID = build.respID
                    res = self.add_floor(buildID,floorMin,floorMax,respID,mode)
            elif editField=='delete':
                log_tools.log_request(user_info['username'],'减少楼层',param)
                for floor_range in editRes:
                    try:
                        floorMin,floorMax = int(floor_range[0]),int(floor_range[1])+1
                        mode = 'number'
                    except:
                        floorMin,floorMax = ord(floor_range[0].lower())-ord('a'),ord(floor_range[1].lower())-ord('a')+1
                        mode = 'alpha'
                    res = self.delete_floor(buildID,floorMin,floorMax,mode)
            else:
                res = {"code":1301,"data":"ERROR: Args error"}
                log_tools.log_response(res)
                return JsonResponse(res)
            log_tools.log_response(res)
            return JsonResponse(res)
        else:
            res = {"code":1301,"data":"ERROR: Args error"}
            log_tools.log_response(res)
            return JsonResponse(res)

# 计划管理
class PlanManager(View):
    # 获取节点信息
    def get(self,request):
        try:
            token = request.GET.get('token','')
            singleID = int(request.GET.get("singleId",""))
            projectID = int(request.GET.get("projectId",""))
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not singleID or not projectID or not token:
            log_tools.log_param_error('获取节点信息',[token,singleID,projectID])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取节点信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取节点信息',request.GET)
        try:
            phases = PhaseInfo.objects.filter(singleID=singleID)
            project = ProjectInfo.objects.get(projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        data = {"planManagement":{}}
        data.update({
            "projectName":project.projectName,
            "baseInfo":{
                "projectFormats":project.projectFormats,
                "conCommDate":get_date(project.conCommDate),
                "conCompDate":get_date(project.conCompDate),
                "awarDate":get_date(project.awarDate),
                "commDate":get_date(project.commDate),
                "permitDate":get_date(project.permitDate),
                "continueDate":get_date(project.continueDate),
            }, 
        })
        for phase in phases:
            phase_name = phase.phaseName
            data["planManagement"][phase_name] = {"eventId":[],"nodeMsg":[],"deadline":[],"acturalTime":[],'right':[]}
            nodes = NodeInfo.objects.filter(phaseID=phase.phaseID)
            for node in nodes:
                data["planManagement"][phase_name]["eventId"].append(node.nodeID)
                data["planManagement"][phase_name]["nodeMsg"].append(node.nodeName)
                data["planManagement"][phase_name]["deadline"].append(get_date(node.deadline))
                data["planManagement"][phase_name]["right"].append(node.right)
                if node.finishTime:
                    finish = get_date(node.finishTime)
                else:
                    finish=''
                data["planManagement"][phase_name]["acturalTime"].append(finish)
        res = {"code":1018,"data":data}
        log_tools.log_response(res)
        return JsonResponse(res)
    # 新增/修改节点信息
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            mode = param.get('mode','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not mode or not token:
            log_tools.log_param_error('新增/修改节点信息',[token,mode])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('新增/修改节点信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        right = get_right(user_info)
        if mode=='add':
            phaseId=param.get('phaseId','')
            node=param.get('node','')
            deadline=param.get('deadline','')
            if not phaseId or not node or not deadline:
                log_tools.log_param_error('新增节点信息',[phaseId,node,deadline])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            log_tools.log_request(user_info['username'],'新增节点信息',param)
            try:
                dates = deadline.split('-')
                month = dates[1]
                day = dates[2]
                if len(month)==1:
                    month = '0'+month
                if len(day)==1:
                    day = '0'+ day
                deadline = dates[0]+month+day
                phaseId = int(phaseId)
                deadline = int(deadline)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                nodes = NodeInfo.objects.filter(phaseID=phaseId)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            now_max = get_max_id('nodes',nodes)
            nodeID = now_max+1 if now_max!=0 else phaseId*100+11
            try:
                NodeInfo.objects.create(
                    nodeID=nodeID,
                    nodeName=node,
                    uploadPeople=user_info['userid'],
                    deadline=deadline,
                    finishState=0,
                    phaseID=phaseId,
                    right=right
                )
            except:
                log_tools.log_error(traceback.format_exc())
                res = {"code":1332,"data":"Add node error"}
            else:
                res = {'code':1211,'data':'Add node ok'}
            log_tools.log_response(res)
            return JsonResponse(res)

        elif mode=='modify':
            nodeID=param.get('nodeId','')
            deadline=param.get('deadline','')
            if not nodeID or not deadline:
                log_tools.log_param_error('修改节点信息',[nodeID,deadline])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            log_tools.log_request(user_info['username'],'修改节点信息',param)
            try:
                dates = deadline.split('-')
                month = dates[1]
                day = dates[2]
                if len(month)==1:
                    month = '0'+month
                if len(day)==1:
                    day = '0'+ day
                deadline = dates[0]+month+day
                nodeID = int(nodeID)
                deadline = int(deadline)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                node = NodeInfo.objects.get(nodeID=nodeID)
                node.deadline = deadline
                node.save()
            except:
                log_tools.log_error(traceback.format_exc())
                res = {"code":1333,"data":"Modify node error"}
            else:
                res = {'code':1212,'data':'Modify node success'}
            log_tools.log_response(res)
            return JsonResponse(res)
        else:
            log_tools.log_response({"code":1301,"data":"ERROR: Args error"})
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})

# 形象进度
class Schedule(View):
    # 获取简报
    def get(self,request):
        try:
            token = request.GET.get('token','')
            moduleID = int(request.GET.get("moduleId",""))
            projectID = int(request.GET.get("projectId",""))
            mode = request.GET.get("mode","finish")
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not moduleID or not projectID or not token:
            log_tools.log_param_error('新增大事件',[token,moduleID,projectID])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取指定楼层工程简报时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取指定楼层工程简报',request.GET)
        try:
            project = ProjectInfo.objects.get(projectID=projectID)
            module = ModuleInfo.objects.get(moduleID=moduleID)
            if mode=='finish':
                schedules = ScheduleInfo.objects.filter(moduleID=moduleID,finishState=1)
            elif mode=='all':
                schedules = ScheduleInfo.objects.filter(moduleID=moduleID)
        except:
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        data = {
            "info":'',
            "projectName":project.projectName,
            "scheduleId":[],
            "workbulletin":[],
            "finishTime":[],
            "worker":[],
            "imgList":[],
            'completeDate':[]
            }
        has_tag = 0
        for sch in schedules:
            if not has_tag:
                data["scheduleId"].append(str(sch.scheduleID))
                data["workbulletin"].append(sch.scheduleName)
                data["finishTime"].append(get_date(sch.finishTime))
                data["completeDate"].append(get_date(sch.realFinishTime))
                user = UserInfo.objects.get(No=sch.uploadPeople)
                data["worker"].append(user.userName)
                if module.finishiTag!='all' and int(sch.scheduleID)==int(module.finishiTag):
                    has_tag=1
            else:
                data["scheduleId"].insert(-1,str(sch.scheduleID))
                data["workbulletin"].insert(-1,sch.scheduleName)
                data["finishTime"].insert(-1,get_date(sch.finishTime))
                data["completeDate"].insert(-1,get_date(sch.realFinishTime))
                data["worker"].insert(-1,UserInfo.objects.get(No=sch.uploadPeople).userName)
            img_list = []
            try:
                imgs = ImageInfo.objects.filter(mapID=sch.scheduleID)
            except:
                continue
            for img in imgs:
                img_list.append(img.imgPath)
            if not has_tag:
                data["imgList"].append(img_list)
            else:
                data["imgList"].insert(-2,img_list)
        floorID = moduleID//100
        buildID = floorID//1000
        singleID = buildID//100
        blockID = singleID//100
        floor = FloorInfo.objects.get(floorID=floorID)
        if floor.floorID%1000>=300:
            floor = chr(floor.floorID%100-1+ord('a'))+'层'
        else:
            if floor.floorNum<0:
                floor = '负'+str(floor.floorNum)[1:]
            else:
                floor = str(floor.floorNum)
        build = BuildInfo.objects.get(buildID=buildID)
        single = SingleInfo.objects.get(singleID=singleID)
        block = BlockInfo.objects.get(blockID=blockID)
        data['info'] = '{}-{}-{}-{}'.format(block.blockName,single.singleName,build.buildName,floor)
        res = {'code':1015,'data':data}
        log_tools.log_response(res)
        return JsonResponse(res)
    
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            moduleID = int(param.get('moduleID',''))
            scheduleDict = param.get('schedules',{})
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('修改简报时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            buildId = moduleID//100000
            module_type = moduleID%100
            floors = FloorInfo.objects.filter(buildID=buildId)
            with transaction.atomic():
                for floor in floors:
                    # 该楼层中对应的module的ID
                    moduleID = floor.floorID*100+module_type
                    scheduleDict_temp = {int(sch_id)%100:scheduleDict[sch_id] for sch_id in scheduleDict}
                    module = ModuleInfo.objects.get(moduleID=moduleID)
                    schedules = ScheduleInfo.objects.filter(moduleID=moduleID)
                    total = module.total
                    finish_count = module.finishCount
                    finish_tag = module.finishiTag

                    if schedules.count():
                        now_max = schedules.order_by('scheduleID').last().scheduleID+1
                    else:
                        now_max = moduleID*10+1
                    for sch in schedules:
                        sch_id = sch.scheduleID
                        temp_sch_type = sch_id%100
                        if temp_sch_type not in scheduleDict_temp:
                            if sch.finishState:
                                finish_count-=1
                            if finish_tag!='all' and int(sch_id)==int(finish_tag):
                                finish_tag=0
                            sch.delete()
                            total-=1
                        else:
                            del scheduleDict_temp[temp_sch_type]
                    for sch in scheduleDict_temp:
                        ScheduleInfo.objects.create(
                            scheduleID=now_max,
                            uploadPeople=user_info['userid'],
                            scheduleName=scheduleDict_temp[sch],
                            moduleID=moduleID,
                            finishState=0,
                        )
                        total+=1
                        now_max+=1
                    if finish_tag==0:
                        schedules = ScheduleInfo.objects.filter(moduleID=module.moduleID)
                        if schedules:
                            finish_tag = schedules.order_by('scheduleID').last().scheduleID
                        else:
                            finish_tag = 'all'
                    module.total = total
                    module.finishCount = finish_count
                    module.finishiTag = finish_tag
                    module.save()
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Modify schedule error"})
        res = {"code":1216,"data":"modify schedule successfully"}
        log_tools.log_response(res)
        return JsonResponse(res)

# 通知信息
class Notice(View):
    def get(self,request):
        try:
            token = request.GET.get('token','')
            projectID = int(request.GET.get("projectId",""))
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not projectID or not token:
            log_tools.log_param_error('获取通知信息',[token,projectID])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        try:
            projectID=int(projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取通知信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'获取通知信息',request.GET)
        try:
            notices = NoticeInfo.objects.get(projectID=projectID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        if not notices:
            cur_index = projectID*100+1
            m = '暂无通知'
            NoticeInfo.objects.create(noticeID=cur_index,noticeMsg=m,projectID=projectID)
            data = [[cur_index,m]]
        else:
            data = [[notices.noticeID,notices.noticeMsg]]
        res = {'code':1019,'data':data}
        log_tools.log_response(res)
        return JsonResponse(res)
    
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            mode = param.get('mode','add')
            projectId = int(param.get('projectId',''))
            msg = param.get('msg',[])
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not mode or not projectId:
            log_tools.log_param_error('修改通知信息',[token,mode,projectId])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('修改通知信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        if mode=='add':
            log_tools.log_request(user_info['username'],'修改通知信息',param)
            if msg:
                try:
                    notice = NoticeInfo.objects.get(projectID=projectId)
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                notice.noticeMsg = msg[0]
                notice.save()
            return JsonResponse({"code":1109,"data":"Modify notice  successfully"})
        elif mode=='sendMsg':
            log_tools.log_request(user_info['username'],'短信通知',param)
            reciever = []
            try:
                with transaction.atomic():
                    relations = RelationInfo.objects.filter(projectID=projectId)
                    for relation in relations:
                        user = UserInfo.objects.get(No=relation.userID)
                        reciever.append(user.tel)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1337,"data":"[FUN ERROR] Get phones error"})
            if not reciever:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1338,"data":"[FUN ERROR] No recieve"})
            jobs = []
            for rec in reciever:
                job = Process(target=send_msg,args=(rec,msg[0]))
                job.start()
                jobs.append(job)
            try:
                [job.join() for job in jobs]
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1338,"data":"[FUN ERROR] Close process error"})
            return JsonResponse({"code":1020,"data":"[FUN ERROR] No recieve"})

# 轮播图相关                 
class Imgs(View):
    def get(self,request):
        try:
            token = request.GET.get('token','')
            project_id = request.GET.get('projectId','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not project_id:
            log_tools.log_param_error('查询项目轮播图',[token,project_id])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取项目轮播图时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'查询项目轮播图',request.GET)
        images =  ImageInfo.objects.filter(mapID=project_id)
        if images:
            imgs_data = [[img.imgID,img.imgPath] for img in images]
            imgs_data.sort(key=lambda img:img[0])
            data = [img[1] for img in imgs_data]
            res = {"code":1003,"data":data}
        else:
            res = {"code":1339,"data":"ERROR: Get img failed"}
        log_tools.log_response(res)
        return JsonResponse(res)

    def post(self,request):
        try:
            param = json.loads(request.body)
            token=param.get('token','')
            imgs=param.get('imgPath',[])
            projectId=param.get('projectId','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not imgs or not projectId:
            log_tools.log_param_error('修改轮播图',[token,imgs,projectId])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('修改轮播图时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            projectId = int(projectId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        log_tools.log_request(user_info['username'],'修改轮播图',param)
        old_imgs = ImageInfo.objects.filter(mapID=projectId)
        try:
            with transaction.atomic():
                for oi in old_imgs:
                    if oi.imgPath not in imgs:
                        oi.delete()
                    else:
                        imgs.remove(oi.imgPath)
                for ni in imgs:
                    # 新增
                    while True:
                        first = ImageInfo.objects.all().order_by('imgID').last().imgID
                        second = ImageInfo.objects.all().order_by('imgID').last().imgID
                        if first==second:
                            now_max = first
                            break
                    imgID = now_max+1 if now_max!=0 else 100000
                    ImageInfo.objects.create(imgID=imgID,imgPath=ni,mapID=projectId)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1339,"data":"ERROR: Insert img failed"})
        res = {"code":1214,"data":"ERROR: Insert img successfully"}
        log_tools.log_response(res)
        return JsonResponse(res)



