# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0004_auto_20210307_1423'),
    ]

    operations = [
        migrations.AlterField(
            model_name='relationinfo',
            name='relationID',
            field=models.IntegerField(verbose_name='关联关系编号', primary_key=True, unique=True, serialize=False),
        ),
        migrations.AlterField(
            model_name='unitsinfo',
            name='tel',
            field=models.CharField(verbose_name='电话', max_length=14),
        ),
    ]
