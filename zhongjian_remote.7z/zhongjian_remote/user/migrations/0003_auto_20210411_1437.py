# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0002_auto_20210307_1401'),
    ]

    operations = [
        migrations.AlterField(
            model_name='userinfo',
            name='tel',
            field=models.CharField(verbose_name='电话', max_length=14),
        ),
    ]
