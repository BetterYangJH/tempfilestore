// pages/user/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    openid:"",
    usermes:{
      name:"",
      tel:"13000000000",
      department:"工程部",
      position:"工程师"
    },
    projectlist:[
      "项目A",
      "项目B",
      "项目C",
      "项目D",
      "项目E",
    ]

  },
  // 按钮绑定登录事件，触发后将用户信息保存到缓存中，并且刷新当前页面
  handleGetUserInfo(e){
    console.log(e)
    const {userInfo}=e.detail;
    wx.setStorageSync('userinfo',userInfo);
    // 刷新当前页面
    this.onLoad();
    this.onShow();
    wx.login({
      success:function(res){
        wx.request({
          url: 'https://30paotui.com/user/wechat',
          data:{
            appid:"wx58638875b488bcef",
            sercet:"f5aee63f2d21f34fa17964cef9bc2d74",
            code:res.code
          },
          success:function (response) {
            var openid = response.data.openid;
            console.log(openid)
            wx.setStorageSync('openid', openid)
            this.setData({
              openid:openid
            })
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  // 将缓存中的个人信息赋值到变量中
  onShow: function () {
    const userinfo = wx.getStorageSync('userinfo')
    this.setData({
      userinfo
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})