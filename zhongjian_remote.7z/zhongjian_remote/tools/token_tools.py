import jwt
import traceback
from zhongjian_back.settings import SECRET_KEY
from user.models import UserInfo
from tools import log_tools
def make_token(username,userId):
    try:
        payload = {
            'username': username, 
            'userid':userId
        }
    except:
        log_tools.log_error(traceback.format_exc())
        return 'error'
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def get_payload(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
    except:
        log_tools.log_error(traceback.format_exc())
        return 'error'
    return payload
    
def get_right(payload):
    userid = payload['userid']
    try:
        user = UserInfo.objects.get(No=userid)
    except:
        log_tools.log_error(traceback.format_exc())
        return 'error'
    else:
        position_id = user.positionID
        if position_id==99999910:return 3
        elif position_id%10000==1010:return 2
        elif position_id%100==10:return 1
        else:return 0