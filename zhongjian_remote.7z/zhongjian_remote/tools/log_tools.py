import os
import time

def format_log(string,log_path):
    cmd = 'echo "{}" >> {}'.format(string,log_path)
    os.system(cmd)

def log_error(error):
    now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    log_path = 'error_log.log'
    format_log('===========================================',log_path)
    format_log('[ERROR_TIME] {}'.format(now),log_path)
    format_log(error,log_path)

def log_request(user,handle,params):
    now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    log_path = 'format_log.log'
    format_log('===========================================',log_path)
    format_log('[REQUEST_TIME] {}'.format(now),log_path)
    format_log('[REQUEST_INFO] {} 执行了 {}'.format(user,handle),log_path)
    format_log('[REQUEST_ARGS] {}'.format(params),log_path)

def log_response(response):
    now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    log_path = 'format_log.log'
    format_log('===========================================',log_path)
    format_log('[RESPONSE_TIME] {}'.format(now),log_path)
    format_log('[RESPONSE_INFO] {}'.format(response),log_path)

def log_param_error(handle,args_list):
    now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    log_path = 'error_log.log'
    format_log('===========================================',log_path)
    format_log('[ERROR_TIME] {}'.format(now),log_path)
    for arg in args_list:
        if not arg:
            format_log('{} 时缺少参数 {}'.format(handle,eval(arg)),log_path)