from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(UserInfo)
class UserInfoAdmin(admin.ModelAdmin):
    # 显示字段 - 所有字段
    list_display = ['No', 'secretID','userID','userName','tel','departmentID','positionID','rightLevel','insertData','updateData']
    # 分组字段
    list_filter  = ['rightLevel',]
    # 每页最大显示数
    list_per_page = 20
    # 排序字段 - 主键
    ordering = ('No','updateData')
    # 搜索字段 - 索引
    search_fields = ('secretID','userName','departmentID','updateData')

@admin.register(PositionInfo)
class PositionInfoAdmin(admin.ModelAdmin):
    list_display = ['positionID', 'positionName','insertData','updateData']
    list_per_page = 20
    ordering = ('positionID','updateData')
    search_fields = ('positionID','positionName','updateData')

@admin.register(DepartmentInfo)
class DepartmentInfoAdmin(admin.ModelAdmin):
    list_display = ['departmentID', 'departmentName','projectID','insertData','updateData']
    list_per_page = 20
    ordering = ('departmentID','updateData')
    search_fields = ('departmentID','departmentName','updateData')
