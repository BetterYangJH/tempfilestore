# -*- coding:UTF-8 -*-
import os,sys,django
os.environ['DJANGO_SETTINGS_MODULE'] = 'zhongjian_back.settings'
django.setup()
from user.models import *
from index.models import *
from add_info import main
# 添加用户
def add_user():
    print('[1/15] 添加人员')
    user_id = 10000
    infos = [
        ['熊均',100012,10001210,1],
        ['彭万里',100012,10001211,0],
        ['高大山',100012,10001211,0],
        ['谢大海',100012,10001211,0],
        ['马宏宇',100012,10001211,0],
        ['赵鹏',100013,10001310,1],
        ['丘善章',100013,10001311,0],
        ['谢扉',100013,10001311,0],
        ['文峰盛',100013,10001311,0],
        ['肖志坤',100013,10001311,0],
        ['阎登鑫',100014,10001410,1],
        ['马继祖',100014,10001411,0],
        ['程孝先',100014,10001411,0],
        ['宗敬先',100014,10001411,0],
        ['年广嗣',100014,10001411,0],
        ['汤绍箕',100014,10001411,0],
        ['吕显祖',100014,10001411,0],
        ['陈芝文',100015,10001510,1],
        ['黄志斌',100015,10001511,0],
        ['陈彪',100015,10001511,0],
        ['王刚',100015,10001511,0],
        ['官珊瑚',100015,10001511,0],
        ['陈元均',100016,10001610,1],
        ['曾谋',100016,10001611,0],
        ['刘伟',100016,10001611,0],
        ['黄元威',100016,10001611,0],
        ['分公司',999999,99999910,3],
    ]
    for info in infos:
        try:
            UserInfo.objects.create(No=user_id,secretID=str(user_id),userID=user_id,userName=info[0],tel=str(13000000000+user_id),departmentID=info[1],positionID=info[2],rightLevel=info[3])
            user_id+=1
        except Exception as e:
            print('### UserInfo')
            print(info)
            print(e)
            continue
    UserInfo.objects.create(No=user_id,secretID='ouQXp5ZMZji9KIBknLd21SwwRIvo',userID=user_id,userName='栗升卫',tel=str(13000000000+user_id),departmentID=100010,positionID=10001010,rightLevel=2)

# 添加部门表
def add_dept():
    print('[2/15] 添加部门')
    infos = [
        [100000,'未指定',1000,5],
        [100010,'管理层',1000,10],
        [100011,'生产部',1000,10],
        [100012,'商务部',1000,10],
        [100013,'党群部',1000,10],
        [100014,'安全部',1000,10],
        [100015,'技术部',1000,10],

        [100021,'生产子部',1000,10],
        [100022,'商务子部',1000,10],
        [100023,'党群子部',1000,10],
        # [100025,'安全子部',1000,10],
        # [100026,'技术子部',1000,10],

        [999999,'分公司',1000,5]
    ]
    for info in infos:
        try:
            temp = DepartmentInfo.objects.create(departmentID=info[0],departmentName=info[1],projectID=info[2],standard=info[3])
            temp.save()
        except Exception as e:
            print('### DepartmentInfo')
            print(info)
            print(e)
            continue

# 添加职位表
def add_pos():
    print('[3/15] 添加职位')
    infos = [
        [10000000,'未指定',1000],
        [10001010,'项目经理',1000],
        [10001110,'生产部部门经理',1000],
        [10001111,'生产部员工',1000],
        [10001210,'商务部部门经理',1000],
        [10001211,'商务部员工',1000],
        [10001310,'党群部部门经理',1000],
        [10001311,'党群部员工',1000],
        [10001410,'安全部部门经理',1000],
        [10001411,'安全部员工',1000],
        [10001510,'技术部部门经理',1000],
        [10001511,'技术部员工',1000],
        
        [10002210,'生产子部部门经理',1000],
        [10002211,'生产子部员工',1000],
        [10002310,'商务子部部门经理',1000],
        [10002311,'商务子部员工',1000],
        [10002410,'党群子部部门经理',1000],
        [10002411,'党群子部员工',1000],
        # [10002510,'安全子部部门经理',1000],
        # [10002511,'安全子部员工',1000],
        # [10002610,'技术子部部门经理',1000],
        # [10002611,'技术子部员工',1000],

        [99999910,'分公司经理',1000],
    ]
    for info in infos:
        try:
            temp = PositionInfo.objects.create(positionID=info[0],positionName=info[1])
            temp.save()
        except Exception as e:
            print('### PositionInfo')
            print(info)
            print(e)
            continue

# 添加项目表
def add_pro():
    print('[4/15] 添加项目')
    infos = [
        [1000,'中山大学·深圳建设工程项目施工总承包（1标）','住宅、商业、学校',42,62,24.79,963,10002,10001,10003,10004,10000,'prepare',0]
    ]
    for info in infos:
        try:
            temp = ProjectInfo.objects.create(projectID=info[0],projectName=info[1],projectFormats=info[2],barea=info[3],carea=info[4],
                                            amount=info[5],duration=info[6],conUnit=info[7],supUnit=info[8],advUnit=info[9],surUnit=info[10],desUnit=info[11],
                                            state=info[12],deleted=info[13],projectManager=10027)
            temp.save()
        except Exception as e:
            print('### ProjectInfo')
            print(info)
            print(e)
            continue
    # for i in range(3):
    #     try:
    #         temp = NoticeInfo.objects.create(noticeID=info[0]*100+i,noticeMsg='测试通知{}'.format(i),projectID=info[0])
    #         temp.save()
    #     except Exception as e:
    #         print('### noticeInfo')
    #         print(info)
    #         print(e)
    #         continue

# 添加单位信息表
def add_units():
    print('[5/15] 添加参建单位')
    infos = [
        [10000,'深圳市华阳国际工程设计有限公司','李祥柱','13425157699'],	
        [10001,'浙江江南工程管理股份有限公司','许建华','13336051039'],	
        [10002,'深圳市住宅工程管理站','王鑫','15979005263'],	
        [10003,'浙江江南工程管理股份有限公司','李冬','13456903636'],	
        [10004,'深圳市工勘岩土集团有限公司','陈强','13760306585'],
    ]
    for info in infos:
        try:
            temp = UnitsInfo.objects.create(unitsID=info[0],unitsName=info[1],contect=info[2],tel=info[3])
            temp.save()
        except Exception as e:
            print('### UnitsInfo')
            print(info)
            print(e)
            continue

# 添加人员项目关联表
def add_relation():
    print('[6/15] 添加人员项目关联')
    for i in range(10000,10042):
        try:
            temp = RelationInfo.objects.create(relationID=i*10000+1000,userID=i,projectID=1000)
            temp.save()
        except Exception as e:
            print('### RelationInfo')
            print(e)
            continue

# 添加图片信息表
def add_img():
    print('[7/15] 添加图片')
    infos = [
        [100000,'cloud://cloud-data-path-3gpen56g996e7b6f.636c-cloud-data-path-3gpen56g996e7b6f-1305981001/lb3.jpg',1000],
        [100001,'cloud://cloud-data-path-3gpen56g996e7b6f.636c-cloud-data-path-3gpen56g996e7b6f-1305981001/lb2.jpg',1000],
        [100002,'cloud://cloud-data-path-3gpen56g996e7b6f.636c-cloud-data-path-3gpen56g996e7b6f-1305981001/lb1.jpg',1000],
    ]
    for info in infos:
        try:
            temp = ImageInfo.objects.create(imgID=info[0],imgPath=info[1],mapID=info[2])
            temp.save()
        except Exception as e:
            print('### ImageInfo')
            print(info)
            print(e)
            continue

# 添加标段表 bi
def add_biaoduan():
    print('[8/15] 添加标段')
    infos = [
        [100010,"二标",1000], # bi1
        [100011,"三标",1000], # bi2
        [100012,"四标",1000]  # bi3
    ]
    for info in infos:
        try:
            temp = SegmentInfo.objects.create(segmentID=info[0],segmentName=info[1],projectID=info[2])
            temp.save()
        except Exception as e:
            print('### SegmentInfo')
            print(info)
            print(e)
            continue

# 添加地块表 pl
def add_dikuai():
    print('[9/15] 添加地块')
    infos = [
        [10001010,"地块A",100010],# pl1
        [10001011,"地块B",100010],# pl2
        [10001012,"地块C",100010],# pl3
        [10001110,"地块D",100011],# pl4
        [10001111,"地块E",100011],# pl5
        [10001210,"地块F",100012],# pl6
    ]
    for info in infos:
        try:
            
            temp = BlockInfo.objects.create(blockID=info[0],blockName=info[1],segmentID=info[2])
            temp.save()
        except Exception as e:
            print('### BlockInfo')
            print(info)
            print(e)
            continue

# 添加单体表 pa
def add_danti():
    print('[10/15] 添加单体')
    infos = [
        [1000101010,"图书馆",10001010],# pa1
        [1000101011,"学生服务中心",10001010],# pa2
        [1000101110,"医科组团",10001011],# pa3
        [1000101210,"西区组团",10001012],# pa4
        [1000111010,"高级住宅",10001110],# pa5
        [1000111011,"西区公寓",10001110],# pa6
        [1000111110,"科研楼",10001111],# pa7
        [1000121010,"档案楼",10001210],# pa8
    ]
    for info in infos:
        try:
            temp = SingleInfo.objects.create(singleID=info[0],singleName=info[1],blockID=info[2])
            temp.save()
        except Exception as e:
            print('### SingleInfo')
            print(info)
            print(e)
            continue

# 添加楼栋表 bu
def add_loudong():
    print('[11/15] 添加楼栋')
    infos = [
        [100010101010,"5#",10001,1000101010],# bu1
        [100010101011,"6#",10018,1000101010],# bu1
        [100010101012,"7#",10019,1000101010],# bu1
        [100010101013,"8#",10020,1000101010],# bu1
        [100010101014,"9#",10021,1000101010],# bu1
        [100010101110,"2#",10002,1000101011],# bu2
        [100010101111,"2#",10023,1000101011],# bu2
        [100010101112,"2#",10024,1000101011],# bu2
        [100010101113,"2#",10025,1000101011],# bu2
        [100010111010,"20#",10003,1000101110],# bu3
        [100010111011,"21#",10004,1000101110],# bu4
        [100010111012,"X栋",10006,1000101110],# bu5
        [100010111013,"23#",10007,1000101110],# bu6
        [100010121010,"A栋",10008,1000101210],# bu7
        [100010121011,"B栋",10009,1000101210],# bu8
        [100010121012,"C栋",10011,1000101210],# bu9
        [100010121013,"D栋",10012,1000101210],# bu10
        [100010121014,"E栋",10013,1000101210],# bu11
        [100011101010,"1#",10014,1000111010],# bu12
        [100011101110,"6#",10015,1000111011],# bu13
        [100011111010,"Z栋",10016,1000111110],# bu14
        [100012101010,"Y栋",10014,1000121010],# bu15
    ]
    for info in infos:
        try:
            temp = BuildInfo.objects.create(buildID=info[0],buildName=info[1],respID=info[2],singleID=info[3])
            temp.save()
        except Exception as e:
            print('### BuildInfo')
            print(info)
            print(e)
            continue

# 添加阶段表
def add_jieduan_and_node():
    print('[12/15] 添加阶段和节点')
    defult_node = {
        'prepare':['场地移交','围挡封闭','三通一平','临水临电接驳','办公生活区临设完成','工友村临设完成','正式开工',],
        'onBuild':['基坑支护完成','土方开挖完成','底板浇筑完成','地下室封顶','主体结构封顶','屋面构筑完成','二次结构完成','外架/模架拆除完成','电梯拆除完成','塔吊拆除完成','正式电梯移交','外立面完成','装饰装修完成','正式供水','正式供电','园林绿化完成',],
        'accept':['地基与基础验收','主体结构验收','建筑装饰装修验收','建筑屋面验收','建筑给水排水及采暖验收','建筑电气验收','智能建筑验收','通风与空调验收','电梯验收','建筑节能工程验收','防雷验收','人防验收','水土保持验收','燃气验收','规划验收','环评验收','档案馆验收','竣工初验','消防验收','竣工验收','竣工备案',]
    }
    singles = SingleInfo.objects.all()
    for single in singles:
        phaseNameDict = {1:'prepare',2:"onBuild",3:"accept"}
        for i in range(1,4):
            phaseID = single.singleID*10+i
            try:
                PhaseInfo.objects.create(phaseID=phaseID,phaseName=phaseNameDict[i],singleID=single.singleID)
            except Exception as e:
                print('### PhaseInfo')
                print(e)
                continue
            nodes = defult_node[phaseNameDict[i]]
            for j in range(len(nodes)):
                try:
                    node = nodes[j]
                    NodeInfo.objects.create(nodeID=phaseID*100+10+j,nodeName=node,uploadPeople=10041,
                                            deadline=20180800+i,finishState=0,phaseID=phaseID)
                except Exception as e:
                    print('### NodeInfo')
                    print(e)
                    continue
    nodes = ['合同开工时间','合同竣工时间','中标通知书时间','开工令时间','施工许可证时间','工期顺延时间']
    for i in range(len(nodes)):
        NodeInfo.objects.create(
            nodeID=10000+i,
            nodeName=nodes[i],
            uploadPeople=10041,
            deadline=20210420,
            finishState=0,phaseID=1000)

# 添加楼层表
def add_louceng():
    print('[13/15] 添加楼层')
    infos = [
        [100010101010,-1,10],
        [100010101011,-1,10],
        [100010101012,-1,10],
        [100010101013,-1,10],
        [100010101014,-1,10],
        [100010101110,1,3],
        [100010101111,1,3],
        [100010101112,1,3],
        [100010101113,1,3],
        [100010111010,-1,9],
        [100010111011,1,8],
        [100010111012,1,1],
        [100010111013,1,1],
        [100010121010,1,1],
        [100010121011,1,1],
        [100010121012,1,1],
        [100010121013,1,1],
        [100010121014,1,2],
        [100011101010,-1,3],
        [100011101110,1,2],
        [100011111010,1,2],
        [100012101010,-1,2],
    ]
    for info in infos:
        for i in range(info[1],info[2]+1):
            if i==0:
                continue
            elif i<0:
                floorID = info[0]*1000+200+abs(i)
            else:
                floorID = info[0]*1000+100+abs(i)
            try:
                temp = FloorInfo.objects.create(floorID=floorID,floorNum=i,buildID=info[0])
                temp.save()
            except Exception as e:
                print('### FloorInfo')
                print(info)
                print(e)
                continue

# 添加模块表
def add_module():
    print('[14/15] 添加模块')
    floors = FloorInfo.objects.all().values_list('floorID')
    for f in floors:
        infos = [                          
            [f[0]*100+1,'mainPrograss',f[0],0,4,(f[0]*100+1)*10+4],# 主体
            [f[0]*100+2,'brickwork',f[0],0,4,(f[0]*100+2)*10+4], # 二次结构
            [f[0]*100+3,'plasterer',f[0],0,4,'all'], # 给排水
            [f[0]*100+4,'waterElec',f[0],0,2,'all'], # 电气
            [f[0]*100+5,'fireControl',f[0],0,5,'all'], # 消防
            [f[0]*100+6,'HVACsystem',f[0],0,2,'all'], # 暖通
            [f[0]*100+7,'externalWall',f[0],0,2,(f[0]*100+7)*10+2], # 外立面
            [f[0]*100+8,'doorWindows',f[0],0,5,'all'], # 门窗
            [f[0]*100+9,'fitment',f[0],0,4,(f[0]*100+9)*10+4] # 简装
        ]
        for info in infos:
            ModuleInfo.objects.create(
                moduleID=info[0],
                moduleName=info[1],
                floorID=info[2],
                finishCount=info[3],
                total=info[4],
                finishiTag=info[5]
            )

# 添加形象进度表
def add_jindu():
    print('[15/15] 添加工程简报')
    floors = FloorInfo.objects.all().values_list('floorID')
    for f in floors:
        infos = [
            [f[0]*1000+11,10000,'架体搭设完成',f[0]*100+1],
            [f[0]*1000+12,10000,'钢筋绑扎完成',f[0]*100+1],
            [f[0]*1000+13,10000,'模板安装完成',f[0]*100+1],
            [f[0]*1000+14,10000,'混凝土浇筑完成',f[0]*100+1],
            [f[0]*1000+21,10000,'植筋完成',f[0]*100+2],
            [f[0]*1000+22,10000,'反坎完成',f[0]*100+2],
            [f[0]*1000+23,10000,'砌筑完成',f[0]*100+2],
            [f[0]*1000+24,10000,'抹灰完成',f[0]*100+2],
            [f[0]*1000+31,10000,'给水管完成',f[0]*100+3],
            [f[0]*1000+32,10000,'排水管完成',f[0]*100+3],
            [f[0]*1000+33,10000,'空调水管完成',f[0]*100+3],
            [f[0]*1000+34,10000,'水表完成',f[0]*100+3],
            [f[0]*1000+41,10000,'强电完成',f[0]*100+4],
            [f[0]*1000+42,10000,'弱电完成',f[0]*100+4],
            [f[0]*1000+51,10000,'消防水完成',f[0]*100+5],
            [f[0]*1000+52,10000,'消防电完成',f[0]*100+5],
            [f[0]*1000+53,10000,'烟感完成',f[0]*100+5],
            [f[0]*1000+54,10000,'应急照明完成',f[0]*100+5],
            [f[0]*1000+55,10000,'末端完成',f[0]*100+5],
            [f[0]*1000+61,10000,'新风完成',f[0]*100+6],
            [f[0]*1000+62,10000,'排风完成',f[0]*100+6],
            [f[0]*1000+71,10000,'基层完成',f[0]*100+7],
            [f[0]*1000+72,10000,'面层完成',f[0]*100+7],
            [f[0]*1000+81,10000,'门框完成',f[0]*100+8],
            [f[0]*1000+82,10000,'门扇完成',f[0]*100+8],
            [f[0]*1000+83,10000,'窗框完成',f[0]*100+8],
            [f[0]*1000+84,10000,'固定玻璃完成',f[0]*100+8],
            [f[0]*1000+85,10000,'开启扇完成',f[0]*100+8],
            [f[0]*1000+91,10000,'墙面完成',f[0]*100+9],
            [f[0]*1000+92,10000,'天面完成',f[0]*100+9],
            [f[0]*1000+93,10000,'地面完成',f[0]*100+9],
            [f[0]*1000+94,10000,'移交完成',f[0]*100+9],
        ]
        for info in infos:
            try:
                temp = ScheduleInfo.objects.create(
                    scheduleID=info[0],
                    uploadPeople=info[1],
                    scheduleName=info[2],
                    moduleID=info[3],
                    finishState=0,
                )
                temp.save()
            except Exception as e:
                print('### ScheduleInfo')
                print(info)
                print(e)
                continue


add_user()
add_dept()
add_pos()
add_pro()
add_units()
add_relation()
add_img()
add_biaoduan()
add_dikuai()
add_danti()
add_loudong()
add_jieduan_and_node()
add_louceng()
add_module()
add_jindu()
main()