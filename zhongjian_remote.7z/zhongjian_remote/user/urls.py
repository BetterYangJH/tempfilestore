from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^projects$', views.Projects.as_view()),
    url(r'^$', views.User.as_view()),
]