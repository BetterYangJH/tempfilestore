# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0008_moduleinfo_finishitag'),
    ]

    operations = [
        migrations.AddField(
            model_name='moduleinfo',
            name='total',
            field=models.IntegerField(verbose_name='简报总数量', default=4),
            preserve_default=False,
        ),
    ]
