// pages/bigEvent/index.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList: [],
    imgs_list:[
      {
        id:0,
        icon: "/images/unlogin.png",
        img: ["/images/bigevent01.png", "/images/bigevent01.png", "/images/bigevent01.png"],
        user_name:"张三",
        time:"2020-11-10",
        currentProject:"项目A",
        currentStage:"阶段A",
        flag:false
      },
      {
        id:2,
        icon:"/images/unlogin.png",
        img: ["/images/bigevent02.png", "/images/bigevent02.png", "/images/bigevent02.png"],
        user_name: "李四",
        time: "2020-11-11",
        currentProject: "项目B",
        currentStage: "阶段B",
        flag:false
      }

    ],
    array: ['签订合同', '购买材料', '动工', '中期结束',"结项"],
    objectArray: [
      {
        id: 0,
        name: '签订合同'
      },
      {
        id: 1,
        name: '购买材料'
      },
      {
        id: 2,
        name: '动工'
      },
      {
        id: 3,
        name: '中期结束'
      },
      {
        id: 4,
        name: '结项'
      }
    ],
    item_index: 1,
    add_mes:"",
    focus:false,

    inputValue:"",
    // 顶部选项菜单
    activeTab: 1,


  },

  // 绑定按钮事件切换动态信息和工程简报，点击不同按钮同步不同数据，并刷新页面
changepage:function (e) {
  console.log(e.currentTarget.dataset.page)
  var onshowpage = e.currentTarget.dataset.page
  if(onshowpage == "mes"){
    this.setData({
      imgs_list: this.data.imgs_list
    })
    this.onLoad()
    this.onShow()
  }
  else{
    this.setData({
      imgs_list: this.data.imgs_list
    })
    this.onLoad()
    this.onShow()
  }
  // :
  // dataset: {
  //   page
},


// 搜索框
  //input.js
  // 获取搜索框的值
  getsearchword:function (e) {
    this.setData({
      inputValue: e.detail.value
    })
    
  },
  //绑定搜索事件， 获取输入框的值之后，请求后端接受数据，然后再重新渲染加载页面
  bindButtonTap: function (e) {
    var inputValue = this.data.inputValue
    console.log(inputValue)
  this.setData({
    focus: true
  })
},
 
  // // 绑定下拉菜单事件,获取当前选择的任务描述
  // bindPickerChange: function (e) {
  //   // console.log('picker发送选择改变，携带值为', e.detail.value)
  //   // const i = e.detail.value;
  //   // console.log(i)
  //   var that = this
  //   this.setData({
  //     item_index:e.detail.value
  //   })
  //   console.log(that.__data__.array[e.detail.value])
  //   this.add_mes = that.__data__.array[e.detail.value]

  // },

  addevent:function(e) {
    console.log("---")
    wx.navigateTo({
      url: '/pages/addEvent/addevent',
    })
  },

  delMes(e){
    let that = this;
    console.log(e.currentTarget.dataset.index,"-------------------")
    var cur_index = e.currentTarget.dataset.index
    wx.showModal({
      // cancelColor: 'cancelColor',
      title:"删除",
      content:"确定删除？",
      success(res){
        if (res.confirm){
          console.log("点击确认")
          var img_list = that.__data__.imgs_list;
          for(var item in img_list){
            console.log(item)
            if (img_list[item]["id"] == cur_index){
              // console.log(item)
              cur_index = item
            }
          }
          img_list.splice(cur_index,1)
          console.log(img_list,"++++++++++")
          wx.setStorageSync('addevent', img_list)
          // that.onLoad()
          // that.onShow()
          that.setData({
            imgs_list: wx.getStorageSync('addevent')
          })
        }
        else{
          console.log("取消")
        }
      },
    })


  },



        // 将图片上传到服务器端，功能待完善
        // wx.cloud.uploadFile({
        //   cloudPath: timestamp + '.png',
        //   filePath: chooseResult.tempFilePaths[0],
        //   success: res => {
        //     wx.hideLoading()
        //     console.log('loaded', res)
        //     that.setData({
        //       imgUrl: res.fileID
        //     })
        //     that.addImgList(res.fileID)
        //   }
        // })

  // 将添加的图片显示到下边列表中
  //添加到图片列表
  // addImgList(imgurl) {
  //   console.log("------------")
  //   console.log(imgurl)
  //   imgs=imgurl;
  //   let that = this;
  //   let timestamp = Date.parse(new Date());
  //   let yhdm = (wx.getStorageSync('userInfo').nickName);
  //   wx.cloud.database().collection('dataList').add({
  //     data: {
  //       name: yhdm,
  //       imgUrl: imgurl,
  //       //time:new Date()
  //     },
  //     success(res) {
  //       console.log("success", res)
  //       that.getImageList();
  //     }, fail(res) { console.log(res) }
  //   })

  // },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("重新加载页面")
    if (wx.getStorageSync('addevent') != "") {
      var imgs_list = wx.getStorageSync('addevent')
      console.log(imgs_list)
      this.setData({
        imgs_list: imgs_list
      })
    }
    else {
      var imgs_list = this.data.imgs_list
      console.log(imgs_list)
      this.setData({
        imgs_list: imgs_list
      })
    }


   

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})