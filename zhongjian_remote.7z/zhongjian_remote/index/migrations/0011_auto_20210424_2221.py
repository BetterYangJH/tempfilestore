# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0010_auto_20210424_1705'),
    ]

    operations = [
        migrations.AddField(
            model_name='projectinfo',
            name='continueDate',
            field=models.IntegerField(verbose_name='竣工顺延时间', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='awarDate',
            field=models.IntegerField(verbose_name='中标通知书日期', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='commDate',
            field=models.IntegerField(verbose_name='开工令日期', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='conCommDate',
            field=models.IntegerField(verbose_name='合同开工日期', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='conCompDate',
            field=models.IntegerField(verbose_name='合同竣工日期', null=True),
        ),
    ]
