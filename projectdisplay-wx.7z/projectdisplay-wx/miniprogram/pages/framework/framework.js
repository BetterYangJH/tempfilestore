// pages/framework/framework.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name_dict:{
      pm_name:"栗升卫",
      part_names:[
        {
          part_name:"生产经理",
          name:"熊均",
          underling:["a"]
        },
        {
          part_name:"安全总监",
          name: "陈芝文",
          underling: ["b", "c", "d"]
        },
        {
          part_name:"技术部",
          name: "陈元均",
          underling: ["a", "b", "d"]
        },
        {
          part_name:"商务部",
          name: "赵鹏",
          underling: ["a", "b", "c"]
        },
        {
          part_name:"党群部",
          name: "阎登鑫",
          underling: ["a", "b", "c", "d"]
        },
      ]
    },
    detail_people:"",
    is_show:false,
    old_index:-1,
    leader_list:["张三","李四","王五","赵六"],
    changed_leader:""
  },
  
  
  show_detail:function (e) {
    console.log(e.currentTarget.dataset.index)
    var index = e.currentTarget.dataset.index
    console.log(this.data.old_index)
    if(index==this.data.old_index){
      this.setData({
        is_show:false,
        old_index:-1,
      })
    }
    else{
      this.setData({
        is_show:true,
        detail_people: this.data.name_dict.part_names[index],
        old_index:index

      })

    }
    console.log(this.data.name_dict.part_names[index].underling)
    
  },

  changeleader:function (e) {
  // console.log(e)
  this.showModal();
  //   // var leader_list = this.data.leader_list
  //   var change_name = ""
  //   // wx.showActionSheet({
    //   //   itemList: this.data.leader_list,
    //   //   success: function (res) {
      //   //     var change_name = leader_list[res.tapIndex]
      //   //   }
      //   //   })
      //   var detail_people = that.data.detail_people
      //   detail_people.name = this.data.changed_leader
      //   that.setData({
        //     name_dict:tmp_name_dict,
        //     detail_people: detail_people
        
        //   })
      },
      
changeok:function (e) {
        
        let that=this
    
    var cur_index = that.data.old_index
    var tmp_name_dict = that.data.name_dict
    tmp_name_dict.part_names[cur_index].name=this.data.changed_leader
    var detail_people = that.data.detail_people
    detail_people.name = this.data.changed_leader
    that.setData({
      name_dict: tmp_name_dict,
      detail_people: detail_people

    })

  this.hideModal()
  },

  getsearchword:function (e) {
    console.log(e.detail.value)
    this.setData({
      changed_leader: e.detail.value
    })
  },


  //显示对话框
  showModal: function () {
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})