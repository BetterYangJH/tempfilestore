import traceback
from django.views.generic import View
from django.http import JsonResponse
from django.db.models import Q
from index.models import ProjectInfo,RelationInfo, SegmentInfo, BlockInfo, SingleInfo, BuildInfo, PhaseInfo, NodeInfo, FloorInfo, ModuleInfo, ScheduleInfo
from user.models import UserInfo
from tools.token_tools import get_payload
from tools.get_info import *
from tools import log_tools

# 获取信息
class GetInfo(View):
    def __init__(self):
        self.progress = [
            'mainPrograss',
            'brickwork',
            'plasterer',
            'waterElec',
            'fireControl',
            'HVACsystem',
            'externalWall',
            'doorWindows',
            'fitment'
        ]
        self._parse_dict = {
            "prepare":"施工准备",
            "onBuild":"在建施工",
            "accept":"专项验收",
            "baseInfo":"基础信息",
        }

    def get(self,request):
        try:
            mode = request.GET.get("mode","")
            token = request.GET.get("token","")
            option = request.GET.get("option","all")
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not mode or not token or not option:
            log_tools.log_param_error('查询信息',[token,mode,option])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('查询信息时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        user = UserInfo.objects.get(No=user_info['userid'])
        # 获取标段
        if mode == "segment":
            log_tools.log_request(user_info['username'],'查询信息 - 标段',request.GET)
            if option=='add':
                relation = RelationInfo.objects.get(userID=int(user_info['userid']))
                projectID = relation.projectID
            else:
                try:
                    projectID = request.GET.get("projectID",'')
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1301,"data":"ERROR: Args error"})
                if not projectID:
                    log_tools.log_param_error('查询信息 - 标段',[projectID])
                    return JsonResponse({"code":1301,"data":"ERROR: Args error"})
                try:
                    projectID = int(projectID)
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                segment_all_list = SegmentInfo.objects.filter(projectID=projectID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            segment_list = filter_datas(option,user,segment_all_list,'segment')
            res_data = {"segmentId":[],"segmentName":[]}
            for segment in segment_list:
                res_data["segmentId"].append(segment.segmentID)
                res_data["segmentName"].append(segment.segmentName)
            res_data["segmentId"].append('add')
            res_data["segmentName"].append('新增')
            res = {"code":1004,"data":res_data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取地块
        elif mode == "block":
            log_tools.log_request(user_info['username'],'查询信息 - 地块',request.GET)
            try:
                segmentID = request.GET.get("segmentID","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not segmentID:
                log_tools.log_param_error('查询信息 - 地块',[segmentID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                segmentID = int(segmentID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                block_all_list = BlockInfo.objects.filter(segmentID=segmentID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            block_list = filter_datas(option,user,block_all_list,'block')
            res_data = {"blockId":[],"blockName":[]}
            for block in block_list:
                res_data["blockId"].append(block.blockID)
                res_data["blockName"].append(block.blockName)
            res_data["blockId"].append('add')
            res_data["blockName"].append('新增')
            res = {"code":1005,"data":res_data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取单体
        elif mode == "single":
            log_tools.log_request(user_info['username'],'查询信息 - 单体',request.GET)
            try:
                blockID = request.GET.get("blockID","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not blockID:
                log_tools.log_param_error('查询信息 - 单体',[blockID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                blockID = int(blockID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                single_all_list = SingleInfo.objects.filter(blockID=blockID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            single_list = filter_datas(option,user,single_all_list,'single')
            res_data = {"singleId":[],"singleName":[]}
            for single in single_list:
                res_data["singleId"].append(single.singleID)
                res_data["singleName"].append(single.singleName)
            res_data["singleId"].append('add')
            res_data["singleName"].append('新增')
            res ={"code":1006,"data":res_data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取楼栋
        elif mode == "build":
            log_tools.log_request(user_info['username'],'查询信息 - 楼栋',request.GET)
            try:
                singleID = request.GET.get("singleID","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not singleID:
                log_tools.log_param_error('查询信息 - 楼栋',[singleID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                singleID = int(singleID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                build_all_list = BuildInfo.objects.filter(singleID=singleID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            build_list = filter_datas(option,user,build_all_list,'build')
            res_data = {"buildId":[],"buildName":[]}
            for build in build_list:
                res_data["buildId"].append(build.buildID)
                res_data["buildName"].append(build.buildName)
            res_data["buildId"].append('add')
            res_data["buildName"].append('新增')
            res = {"code":1007,"data":res_data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取阶段
        elif mode=='phase':
            log_tools.log_request(user_info['username'],'查询信息 - 阶段',request.GET)
            try:
                singleID = request.GET.get("singleId","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not singleID:
                log_tools.log_param_error('查询信息 - 阶段',[singleID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                singleID = int(singleID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                phase_list = PhaseInfo.objects.filter(singleID=singleID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            data = {"phaseId":[],"phaseName":[]}
            for phase in phase_list:
                data["phaseId"].append(phase.phaseID)
                data["phaseName"].append(self._parse_dict[phase.phaseName])
            data["phaseId"].insert(0,singleID//1000000)
            data["phaseName"].insert(0,self._parse_dict['baseInfo'])
            res = {"code":1008,"data":data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取未完成节点
        elif mode == "node":
            log_tools.log_request(user_info['username'],'查询信息 - 节点',request.GET)
            try:
                phaseID = request.GET.get("phaseID","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not phaseID:
                log_tools.log_param_error('查询信息 - 节点',[phaseID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                phaseID = int(phaseID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                data = {"nodeId":[],"nodeName":[]}
                # 基础信息
                if phaseID<10000:
                    nodes = NodeInfo.objects.filter(phaseID=phaseID)
                    for node in nodes:
                        if not node.finishState:
                            data["nodeId"].append(node.nodeID)
                            data["nodeName"].append(node.nodeName)
                        else:
                            if node.nodeName=='工期顺延时间':
                                data["nodeId"].append(node.nodeID)
                                data["nodeName"].append(node.nodeName)
                else:
                    nodes = NodeInfo.objects.filter(phaseID=phaseID,finishState=0)
                    for node in nodes:
                        data["nodeId"].append(node.nodeID)
                        data["nodeName"].append(node.nodeName)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            res = {"code":1009,"data":data}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取楼层
        elif mode == "floor":
            log_tools.log_request(user_info['username'],'查询信息 - 楼层及简报',request.GET)
            try:
                buildID = request.GET.get("buildID","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not buildID:
                log_tools.log_param_error('查询信息 - 楼层及简报',[buildID])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                buildID = int(buildID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            try:
                floor_list = FloorInfo.objects.filter(buildID=buildID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            datas = {}
            for floor in floor_list:
                if floor.floorID%1000>=300:
                    floor_name = chr(floor.floorID%100+ord('a'))
                else:
                    floor_name = floor.floorNum
                if floor_name not in datas:
                    datas[floor_name] = {"floorId":floor.floorID,"floorNum":floor_name}
                    for i in self.progress:
                        datas[floor_name][i] = 0
                if option=='all':
                    modules = ModuleInfo.objects.filter(floorID=floor.floorID)
                    for module in modules:
                        datas[floor_name][module.moduleName] = {'finishiCount':module.finishCount,'finishiState':False,'color':'rgba(255,153,51,0.795)'}
                        if module.finishiTag=='all':
                            if module.finishCount==module.total:
                                datas[floor_name][module.moduleName]['finishiState']=True
                                datas[floor_name][module.moduleName]['color']='rgba(19,204,149,0.795)'
                        else:
                            tag_schedule = int(module.finishiTag)
                            if tag_schedule:
                                sch = ScheduleInfo.objects.get(scheduleID=tag_schedule)
                                if sch.finishState==1:
                                    datas[floor_name][module.moduleName]['finishiState']=True
                                    datas[floor_name][module.moduleName]['color']='rgba(19,204,149,0.795)'
            module_info = {}
            if option=='all':
                if modules.count():
                    module_info = {module.moduleName:str(module.moduleID) for module in modules}
            data_list = [v for _,v in datas.items()]
            if data_list and data_list[0]['floorId']%1000>=300:
                data_list.sort(key=lambda x:ord(x["floorNum"]))
            else:
                data_list.sort(key=lambda x:int(x["floorNum"]))
            res = {"code":1010,"data":{"scheduleInfo":data_list,"moduleInfo":module_info}}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取模块
        elif mode == "module":
            log_tools.log_request(user_info['username'],'查询信息 - 模块',request.GET)
            try:
                min_floor = request.GET.get('minFloorID','')
                max_floor = request.GET.get('maxFloorID','')
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not min_floor or not max_floor:
                log_tools.log_param_error('查询信息 - 模块',[min_floor,max_floor])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                min_floor = int(min_floor)
                max_floor = int(max_floor)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            datas = {'moduleId':[],'moduleName':[]}
            
            if min_floor<=max_floor:
                for floorID in range(min_floor,max_floor+1):
                    module_list = ModuleInfo.objects.filter(floorID=floorID)
            else:
                zero_floor = (max_floor//10)*10
                for floorID in range(zero_floor,max_floor+1):
                    module_list = ModuleInfo.objects.filter(floorID=floorID)
                zero_floor = (min_floor//10)*10
                for floorID in range(zero_floor,min_floor+1):
                    module_list = module_list | ModuleInfo.objects.filter(floorID=floorID)
            for module in module_list:
                if module.moduleName not in datas['moduleName'] and module.finishCount<module.total:
                    datas['moduleId'].append(str(module.moduleID))
                    datas['moduleName'].append(module.moduleName)
            res = {"code":1011,"data":datas}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取未完成简报
        elif mode=='schedule':
            log_tools.log_request(user_info['username'],'查询信息 - 未完成简报',request.GET)
            try:
                moduleID = request.GET.get("moduleID","")
                min_floor = request.GET.get('minFloorID','')
                max_floor = request.GET.get('maxFloorID','')
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not moduleID or not min_floor or not max_floor:
                log_tools.log_param_error('查询信息 - 未完成简报',[moduleID,min_floor,max_floor])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                moduleID = int(moduleID)
                min_floor = int(min_floor)
                max_floor = int(max_floor)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
            modult_type = moduleID%100
            schedules = None
            if min_floor<=max_floor:
                for floorID in range(min_floor,max_floor+1):
                    
                    moduleID = floorID*100+modult_type
                    now_schedules = ScheduleInfo.objects.filter(moduleID=moduleID,finishState=0)
                    if not schedules:
                        schedules = now_schedules
                    else:
                        schedules = schedules | now_schedules   
            else:
                zero_floor = (max_floor//10)*10
                for floorID in range(zero_floor,max_floor+1):
                    moduleID = floorID*100+modult_type
                    now_schedules = ScheduleInfo.objects.filter(moduleID=moduleID,finishState=0)
                    if not schedules:
                        schedules = now_schedules
                    else:
                        schedules = schedules | now_schedules
                zero_floor = (min_floor//10)*10
                for floorID in range(zero_floor,min_floor+1):
                    moduleID = floorID*100+modult_type
                    now_schedules = schedules | ScheduleInfo.objects.filter(moduleID=moduleID,finishState=0)
                    if not schedules:
                        schedules = now_schedules
                    else:
                        schedules = schedules | now_schedules
            datas = {"scheduleId":[],"workbulletin":[],"finishTime":[]}
            for sch in schedules:
                if sch.scheduleName not in datas["workbulletin"]:
                    datas["scheduleId"].append(str(sch.scheduleID))
                    datas["workbulletin"].append(sch.scheduleName)
            res = {'code':1012,'data':datas}
            log_tools.log_response(res)
            return JsonResponse(res)

        # 获取同名人
        elif mode=='sameNamePeople':
            log_tools.log_request(user_info['username'],'查询信息 - 同名员工',request.GET)
            try:
                username = request.GET.get("username","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not username:
                log_tools.log_param_error('查询信息 - 同名员工',[username])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                user_list = UserInfo.objects.filter(userName=username)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            res_data = [{'userId':user.No,'userName':user.userName} for user in user_list]
            res = {"code":1002,"data":res_data}
            log_tools.log_response(res)
            return JsonResponse(res)

        elif mode=='nodeInfo':
            log_tools.log_request(user_info['username'],'查询信息 - 单个节点详细信息',request.GET)
            try:
                node_id = request.GET.get("nodeId","")
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            if not node_id:
                log_tools.log_param_error('查询信息 - 单个节点详细信息',[node_id])
                return JsonResponse({"code":1301,"data":"ERROR: Args error"})
            try:
                info = NodeInfo.objects.get(nodeID=node_id)
                user = UserInfo.objects.get(No=info.uploadPeople)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            event,projectID = get_full_info(info,'event')
            if event=='error':
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            try:
                imgs = ImageInfo.objects.filter(mapID=info.nodeID)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            imgs = [img.imgPath for img in imgs]
            if not imgs:
                imgs = ["/images/bigevent01.png"]
            if info.finishTime:
                finish_time = get_date(info.finishTime)
            else:
                finish_time = ''
            data = {
                "eid": info.nodeID,
                "eventMsg": event,
                "imgList": imgs,
                "eventTime": finish_time,
                "upload":user.userName,
                "fullInfo":get_full_info(info)[0],
            }
            res = {'code':1014,'data':data}
            log_tools.log_response(res)
            return JsonResponse(res)
        else:
            return JsonResponse({"code":1301,"data":"ERROR: Args error,unknown mode"})
        