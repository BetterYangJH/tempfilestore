// pages/projectDetial/index.js
var wxCharts = require("../../utils/wxcharts-min.js")
// var ringChart1 = null;
// var ringChart2 = null;
// var ringChart3 = null;
// var ringChart4 = null;
// var ringChart5 = null;
// var ringChart6 = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    projectId: "",
    swiper_img: [
      {
        id: 0,
        img: "/images/lb1.jpg"
      },
      {
        id: 1,
        img: "/images/lb2.jpg"
      },
      {
        id: 2,
        img: "/images/lb3.jpg"
      }
    ],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      projectId: options.projectId
    })
  },
  // 绑定点击单个项目的事件，后期看是否带参传输
  turnToSurver: function () {
    wx.navigateTo({
      url: '/pages/survey/survey',
    })
  },
  turnToframework: function () {
    wx.navigateTo({
      url: "/pages/framework/framework",
    })
  },
  turnTosinglemodel: function () {
    wx.navigateTo({
      url: "/pages/singlemodel/singlemodel",
    })
  },
  turnToplanmanager: function () {
    wx.navigateTo({
      url: "/pages/planmanager/planmanager",
    })
  },
  turnToschedule: function () {
    wx.navigateTo({
      url: "/pages/schedule/schedule",
    })
  },






















  showMesage: function (e) {
    var messageId = e.currentTarget.dataset.id
    console.log(messageId)
    wx.navigateTo({
      url: '/pages/projectDetail_2/index?messageId=' + messageId,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  updateData: function () {

  },
  onReady: function (e) {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})