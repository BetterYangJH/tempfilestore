import sys
import json
import requests
import traceback
from django.conf import settings
from index.models import *
from tools import log_tools

# 获取大事件/工程简报完整信息
def get_full_info(info,mode='event'):
    if mode=='event':
        if info.phaseID<10000:
            return info.nodeName,info.phaseID
        try:
            phase = PhaseInfo.objects.get(phaseID=info.phaseID)
            single = SingleInfo.objects.get(singleID=phase.singleID)
        except Exception as e:
            log_tools.log_error(traceback.format_exc())
            return 'error',None
    else:
        try:
            module = ModuleInfo.objects.get(moduleID=info.moduleID)
            floor = FloorInfo.objects.get(floorID=module.floorID)
            building = BuildInfo.objects.get(buildID=floor.buildID)
            single = SingleInfo.objects.get(singleID=building.singleID)
        except Exception as e:
            log_tools.log_error(traceback.format_exc())
            return 'error',None
    try:
        block = BlockInfo.objects.get(blockID=single.blockID)
        segment = SegmentInfo.objects.get(segmentID=block.segmentID)
    except Exception as e:
        log_tools.log_error(traceback.format_exc())
        return 'error',None
    if mode=='event':
        return "{}-{}-{}-{}".format(
                segment.segmentName,
                block.blockName,
                single.singleName,
                info.nodeName
            ),segment.projectID
    else:
        if floor.floorID%1000>=300:
            floor = chr(floor.floorID%100+ord('a'))+'层'
        else:
            floor = str(floor.floorNum)
            if '-' in floor:
                floor = '负'+floor[1:]
        return "{}-{}-{}-{}-{}-{}".format(
                segment.segmentName,
                block.blockName,
                single.singleName,
                building.buildName,
                floor,
                info.scheduleName
            ),segment.projectID

# 日志格式化
def get_date(row_date):
    """
        20210620 -> 2021.6.20
    """
    if not row_date:
        return ''
    if row_date<100000000:
        year = row_date//10000
        month = row_date%10000//100
        day = row_date%100
        new_date = '{}.{}.{}'.format(year,month,day)
    else:
        year = str(row_date//100000000)
        month = str(row_date//1000000%100)
        if len(month)==1:
            month = '0'+month
        day = str(row_date//10000%100)
        if len(day)==1:
            day = '0'+day
        minute = str(row_date//100%100)
        if len(minute)==1:
            minute = '0'+minute
        second = str(row_date%100)
        if len(second)==1:
            second = '0'+second
        new_date = '{}.{}.{} {}:{}'.format(year,month,day,minute,second)
    return new_date

# 获取用户openid
def get_openid(code):
    url = 'https://api.weixin.qq.com/sns/jscode2session?appid={}&secret={}&js_code={}&grant_type=authorization_code'.format(settings.APP_ID,settings.SECRET,code)
    resq = json.loads(requests.request(method='GET',url=url).text)
    if 'openid' in resq:
        return resq['openid']
    else:
        return 'outtime'

# 获取有权限的层级信息，用于增加大事件/工程简报时的级联菜单
def filter_datas(option,user,org_list,mode):
    rightLevel = user.rightLevel
    # 部门负责人添加大事件/简报 - 返回所有
    if rightLevel>0:
        return org_list
    else:
        # 级联 - 返回所有
        if option=='all':
            return org_list
        # 楼栋负责人添加简报 - 返回有权限的
        elif option=='add':
            res_list = []
            build_list = BuildInfo.objects.filter(respID=user.No)
            if not build_list:
                return []
            if mode=='segment':
                relation_num = 1000000
            elif mode=='block':
                relation_num = 10000
            elif mode=='single':
                relation_num = 100
            elif mode=='build':
                relation_num = 1
            else:
                return []
            charge_id_list = list(set(map(lambda build:(build.buildID)//relation_num,build_list)))
            for info in org_list:
                if mode=='segment' and info.segmentID in charge_id_list:
                    res_list.append(info)
                elif mode=='block' and info.blockID in charge_id_list:
                    res_list.append(info)
                elif mode=='single' and info.singleID in charge_id_list:
                    res_list.append(info)
                elif mode=='build' and info.buildID in charge_id_list:
                    res_list.append(info)
            return res_list

def get_max_id(mode,datas):
    _max = 0
    for data in datas:
        if mode=='project':
            next_id = data.projectID
        elif mode=='nodes':
            next_id = data.nodeID
        elif mode=='builds':
            next_id = data.buildID
        elif mode=='img':
            next_id = data.imgID
        elif mode=='seg':
            next_id = data.segmentID
        elif mode=='block':
            next_id = data.blockID
        elif mode=='single':
            next_id = data.singleID
        _max = next_id if next_id>_max else _max
    return _max

def send_msg(phone,msg):
    print('内容\n{}'.format(msg))
    print('接收人\n{}'.format(phone))

def reset_user(user):
    user.departmentID=100000	
    user.positionID=10000000
    user.rightLevel=0
    user.save()