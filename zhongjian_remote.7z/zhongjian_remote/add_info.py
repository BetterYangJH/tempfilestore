
import os,django
os.environ["DJANGO_SETTINGS_MODULE"] = "zhongjian_back.settings"
django.setup()
from user.models import *
from index.models import *
import requests
import json
md_root = "./user.md"
tel = 13300000000

def add_project(name,user):
    global tel
    url = "https://www.zhongjian888.ltd/index/"
    data = {
            "conUnit":{"name":"单位一","contact":"负责一","tel":tel},
            "supUnit":{"name":"单位二","contact":"负责二","tel":tel+1},
            "advUnit":{"name":"单位三","contact":"负责三","tel":tel+2},
            "surUnit":{"name":"单位四","contact":"负责四","tel":tel+3},
            "desUnit":{"name":"单位五","contact":"负责五","tel":tel+4},
            "projectImgs":["cloud://cloud-data-path-3gpen56g996e7b6f.636c-cloud-data-path-3gpen56g996e7b6f-1305981001/lb3.jpg"],
            "projectManager": user,
            "barea":1,
            "carea":1,
            "amount":1.1,
            "duration":1,
            "projectName":name,
            "projectFormats":"工程",
            "token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6Ilx1NzE4YVx1NTc0NyIsInVzZXJpZCI6MTAwMDB9.Yh3vlQgYTHtjbZL_n8j9YY_FFW-B3aC4bcbNtTl7F6A"
    }
    data = json.dumps(data)
    tel+=5
    req = requests.post(url=url,data=data)
    print(req.text)

def add_user(user_info):
    try:
        if user_info["user_id"]:
            UserInfo.objects.create(
                No=user_info["No"],
                secretID=user_info["No"],
                userID=user_info["user_id"],
                userName=user_info["name"],
                tel=str(user_info["tel"]),
                departmentID=100000,
                positionID=10000000,
                rightLevel=0
            )
        else:
            UserInfo.objects.create(
                No=user_info["No"],
                secretID=user_info["No"],
                userName=user_info["name"],
                tel=str(user_info["tel"]),
                departmentID=100000,
                positionID=10000000,
                rightLevel=0
            )
    except Exception as e:
        print(e)


def format_line(line,info_dict):
    infos = line.split("\t")
    infos = list(filter(lambda x: x!=" ",infos))
    if not infos[1]:
        return
    if infos[1] not in info_dict:
        info_dict[infos[1]] = []
    if infos[4]=="暂无":
        infos[4] = ""
    info_dict[infos[1]].append({"name":infos[2],"position":infos[3],"user_id":infos[4],"tel":infos[5]})

def main():
    print('parse file')
    info_dict = {}
    with open(md_root,"r+") as f:
        contents = f.readlines()
    for line in contents:
        if not line.strip():
            continue
        if "竣工" in line:
            continue
        format_line(line,info_dict)

    manager = {}
    print('add init user')
    user_no = 10000
    for p,u in info_dict.items():
        if p not in manager:
            manager[p] = ""
        for user in u:
            user["No"] = user_no
            user_no+=1
            if user["position"] in ("项目经理","项目副经理","项目执行经理"):
                manager[p] = user["No"]
            if "经理" not in user["position"]:
                temp_manager = user["No"]
            add_user(user)
        if not manager[p]:
            manager[p] = temp_manager

    print('add init project')
    for name,user in manager.items():
        add_project(name,user)

    print('add init relation')
    user_no = 10000
    for p,u in info_dict.items():
        project = ProjectInfo.objects.get(projectName=p)
        for user in u:
            user["No"] = user_no
            user_no+=1
            try:
                RelationInfo.objects.create(relationID=int(user['No'])*10000+project.projectID,userID=user['No'],projectID=project.projectID)
            except:
                continue

    print('modify info')
    user_no = 10000
    for p,u in info_dict.items():
        project = ProjectInfo.objects.get(projectName=p)
        for user in u:
            user["No"] = user_no
            user_no+=1
            right = 0
            if user['position'] in ('项目经理','项目副经理','项目执行经理'):
                project.projectManager = user["No"]
                project.save()
                department_id = project.projectID*100+10
                position_id = department_id*100+10
                right = 2
            elif user['position'] in ('生产经理','生产经理（代）'):
                department_id = project.projectID*100+12
                position_id = department_id*100+10
                right = 1
            elif user['position'] =='生产副经理':
                department_id = project.projectID*100+12
                position_id = department_id*100+11
            else:
                department_id = project.projectID*100+15
                position_id = department_id*100+11
            user = UserInfo.objects.get(No=user["No"])
            user.departmentID = department_id
            user.positionID = position_id
            user.rightLevel = right
            user.save()

if __name__ == '__main__':
    main()
    