//index.js
Page({
  data: {
    // "title":"竣工";

  },
  show_building:function (e) {
    // console.log(e)
    // console.log(e.currentTarget.dataset.name)
    wx.navigateTo({
      url: '/pages/projectList/index?name="building"',
    })
},
  show_prepare: function (e) {
    // console.log(e)
    // console.log(e.currentTarget.dataset.name)
    wx.navigateTo({
      url: '/pages/projectList/index?name="prepare"',
    })
  },
  show_complate: function (e) {
    // console.log(e)
    // console.log(e.currentTarget.dataset.name)
    wx.navigateTo({
      url: '/pages/projectList/index?name="complate"',
    })
  },
})