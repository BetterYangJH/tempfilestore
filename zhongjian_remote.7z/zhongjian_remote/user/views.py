import traceback
from django.views.generic import View
from django.http import JsonResponse
from zhongjian_back.settings import DEBUG
from .models import UserInfo,PositionInfo,DepartmentInfo
from index.models import ProjectInfo,RelationInfo
from tools.token_tools import make_token,get_payload
from tools.get_info import *
from tools import log_tools

# 获取用户信息
class User(View):
    def __init__(self):
        self._right_dict = {
            '部门经理':1,
            '项目经理':2,
            '分公司经理':3
        }
    def get(self,request):
        try:
            code = request.GET.get('code','')
            mode = request.GET.get('mode','code')
            tel = request.GET.get('tel','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not mode or not code:
            log_tools.log_param_error('登录',[mode,code])
            return JsonResponse({"code":1301,"data":"[ERROR: Args error] Missing args:'mode'"})
        try:
            openid = get_openid(code)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1312,"data":"[FUN ERROR] Get openID failed"})
        if openid=='outtime':
            log_tools.log_error('登录时获取openid错误')
            return JsonResponse({"code":1312,"data":"[ERROR: Args error] Get openID failed,code outtime"})
        if mode=='code':
            # 第一步：登录时查找是否登陆过
            try:
                person = UserInfo.objects.get(secretID=openid)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1313,"data":{'userName':''}})
            log_tools.log_request(person.userName,'旧用户登录',request.GET)
        elif mode=='tel':
            # 第二步：未登陆过用手机号匹配
            if not tel:
                log_tools.log_param_error('登录',[tel])
                return JsonResponse({"code":1301,"data":"[ERROR: Args error] Missing args:'tel' or 'userId'"})
            try:
                person = UserInfo.objects.get(tel=tel)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1313,"data":"[DATA ERROR] Unknown user"})
            log_tools.log_request(person.userName,'新用户登录',request.GET)
        try:
            person.secretID=openid
            person.save()
            department = DepartmentInfo.objects.get(departmentID=person.departmentID)
            position = PositionInfo.objects.get(positionID=person.positionID)
            relations = RelationInfo.objects.filter(userID=person.No)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        project_id_list = []
        project_name_list = []
        if person.departmentID==999999:
            projects = ProjectInfo.objects.all()
            for project in projects:
                project_id_list.append(project.projectID)
                project_name_list.append(project.projectName)
        else:
            for pro in relations:
                try:
                    project = ProjectInfo.objects.get(projectID=pro.projectID)
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                if not project.deleted:
                    project_id_list.append(project.projectID)
                    project_name_list.append(project.projectName)
        token = make_token(person.userName,person.No)
        if token=='error':
            log_tools.log_error('登录时解析token错误')
            return JsonResponse({"code":1314,"data":"[FUN ERROR] Get token failed"})
        data_dict = {
                "token":token,
                "No":person.No,
                "userName":person.userName,
                "userId":person.userID,
                "userTel":person.tel,
                "userDepartment":department.departmentName,
                "userPosition":position.positionName,
                "projectList":{
                    "projectId":project_id_list,
                    "projectName":project_name_list
                },
                "right":0,
                "editMode":"editMode",
            }
        try:
            build = BuildInfo.objects.get(respID=person.No)
        except:
            log_tools.log_error(traceback.format_exc())
        else:
            data_dict['respBuild'] = build.buildID
        if position.positionName in self._right_dict:
            data_dict['right']=self._right_dict[position.positionName]
        if '部门经理' in position.positionName:
            data_dict['right']=1
        res = {'code':1001,'data':data_dict}
        log_tools.log_response(res)
        return JsonResponse(res)

class Projects(View):
    def get(self,request):
        try:
            token = request.GET.get('token','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token:
            log_tools.log_param_error('查询相关项目',[token])
            return JsonResponse({"code":1301,"data":"[ERROR: Args error] Missing args:'code'"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('查询相关项目时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'查询相关项目',request.GET)
        relations = RelationInfo.objects.filter(userID=user_info['userid'])
        projectList = {"projectId":[],"projectName":[]}
        for rela in relations:
            project = ProjectInfo.objects.get(projectID=rela.projectID)
            if not project.deleted:
                projectList['projectId'].append(project.projectID)
                projectList['projectName'].append(project.projectName)
        res = {'code':1001,'data':projectList}
        log_tools.log_response(res)
        return JsonResponse(res)
