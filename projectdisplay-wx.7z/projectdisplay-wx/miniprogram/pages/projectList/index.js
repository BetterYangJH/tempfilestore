// pages/projectList/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "",
    projectId: "",
    // 后期从后端获取，
    projectList: [
      {
        id: 0,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋杭州市 x小区 x栋杭州市 x小区 x栋杭州市 x小区 x栋",
        // state:"在建",
        // detail:"整体架构完成，后续粉刷墙面",
        project_id: "1",
        pFormats:"学校"
      },
      {
        id: 1,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋",
        // state: "在建",
        // detail: "整体架构完成，后续粉刷墙面",
        project_id: "2",
        pFormats:"学校"
      },
      {
        id: 2,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋",
        // state: "在建",
        // detail: "整体架构完成，后续粉刷墙面",
        project_id: "3",
        pFormats:"学校"
      },
      {
        id: 3,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋",
        // state: "在建",
        // detail: "整体架构完成，后续粉刷墙面",
        project_id: "4",
        pFormats:"学校"
      },
      {
        id: 4,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋",
        // state: "在建",
        // detail: "整体架构完成，后续粉刷墙面",
        project_id: "5",
        pFormats:"学校"
      },
      {
        id: 5,
        img: "/images/main_img.jpg",
        name: "杭州市 x小区 x栋",
        // state: "在建",
        // detail: "整体架构完成，后续粉刷墙面",
        project_id: "6",
        pFormats:"学校"
      },

    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      name: options.name
    })
    // var name=options.name
    // console.log(name)
  },

  show_detail: function (e) {
    var project_id = String(e.currentTarget.dataset.name)
    console.log(project_id)
    wx.navigateTo({
      url: '/pages/projectDetial/index?projectId=' + project_id,
    })
  },

})