from django.apps import AppConfig


class BigeventConfig(AppConfig):
    name = 'bigevent'
