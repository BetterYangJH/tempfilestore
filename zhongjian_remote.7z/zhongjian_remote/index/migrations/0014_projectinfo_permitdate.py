# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0013_auto_20210426_1952'),
    ]

    operations = [
        migrations.AddField(
            model_name='projectinfo',
            name='permitDate',
            field=models.IntegerField(verbose_name='施工许可证时间', null=True),
        ),
    ]
