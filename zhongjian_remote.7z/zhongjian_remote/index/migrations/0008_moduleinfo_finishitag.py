# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0007_auto_20210424_1239'),
    ]

    operations = [
        migrations.AddField(
            model_name='moduleinfo',
            name='finishiTag',
            field=models.CharField(verbose_name='完成标志', max_length=15, default='all'),
        ),
    ]
