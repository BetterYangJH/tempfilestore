import json
import time
import traceback
from django.views.generic import View
from django.http import JsonResponse
from django.db import transaction
from index.models import NodeInfo,ProjectInfo,ScheduleInfo,ImageInfo,ModuleInfo
from tools.token_tools import get_payload
from tools.get_info import *
from tools import log_tools

# 动态信息 - 大事件
class BigEvent(View):
    # 获取大事件 / 查询大事件
    def get(self,request):
        try:
            token = request.GET.get('token','')
            keyword= request.GET.get('keyword','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token:
            log_tools.log_param_error('获取大事件',[token])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取大事件时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'查询动态信息 - 大事件',request.GET)
        relations = RelationInfo.objects.filter(userID=user_info['userid'])
        infos = 'none'
        for rela in relations:
            projectId = rela.projectID
            project = ProjectInfo.objects.get(projectID=projectId)
            if project.deleted:
                continue
            infos_single = NodeInfo.objects.filter(nodeID__startswith=projectId,finishState=1)
            if infos=='none':
                infos = infos_single
            else:
                infos = infos | infos_single
        infos = infos.order_by('-finishTime')
        data = []
        for info in infos:
            event,projectID = get_full_info(info,'event')
            if event=='error':
                continue
            if keyword=='' or  keyword in event:
                try:
                    project = ProjectInfo.objects.get(projectID=projectID)
                    icons = ImageInfo.objects.filter(mapID=projectID)
                    imgs = ImageInfo.objects.filter(mapID=info.nodeID)
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                imgs = [img.imgPath for img in imgs]
                if not imgs:
                    imgs = ["/images/bigevent01.png"]
                event_info = {
                    "eid": str(info.nodeID),
                    "pIcon": icons[0].imgPath,
                    "pName": project.projectName,
                    "eventMsg": event,
                    "imgList": imgs,
                    "eventTime": get_date(info.finishTime)
                }
                data.append(event_info)
        res = {'code':1014,'data':data}
        log_tools.log_response(res)
        return JsonResponse(res)

    # 新增大事件
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            nodeID = param.get('nodeID','')
            imgPath = param.get('imgPath','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not nodeID or not imgPath:
            log_tools.log_param_error('新增大事件',[token,nodeID,imgPath])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('新增大事件时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            nodeID = int(nodeID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        log_tools.log_request(user_info['username'],'发布动态信息 - 大事件',param)
        try:
            node = NodeInfo.objects.get(nodeID=nodeID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
        upload_time = int(time.strftime('%Y%m%d%H%M',time.localtime(time.time())))
        if nodeID<100000:
            projectId = nodeID//10
            data_type = node.nodeName
            # '合同开工时间', '合同竣工时间', '开工令时间', '施工许可证时间', '工期顺延时间'
            project = ProjectInfo.objects.get(projectID=projectId)
            if data_type=='中标通知书时间':
                project.awarDate = int(upload_time)//10000
            elif data_type=='开工令时间':
                project.commDate = int(upload_time)//10000
            elif data_type=='施工许可证时间':
                project.permitDate = int(upload_time)//10000
                project.state='building'
            elif data_type=='工期顺延时间':
                project.continueDate = int(upload_time)//10000
            project.save()
        try:
            with transaction.atomic():
                current_step = 'node'
                node.uploadPeople = user_info['userid']
                node.finishState = 1
                node.finishTime = upload_time
                node.save()
            if imgPath and isinstance(imgPath,list):
                while True:
                    first = ImageInfo.objects.all().order_by('imgID').last().imgID
                    second = ImageInfo.objects.all().order_by('imgID').last().imgID
                    if first==second:
                        now_max = first
                        break
                imgID = now_max+1 if now_max!=0 else 100000
                current_step = 'img'
                i = 1
                for img in imgPath:
                    temp = ImageInfo.objects.create(
                        imgID=imgID+i,
                        imgPath=img,
                        mapID=nodeID,
                    )
                    temp.save()
                    i+=1
            if '竣工备案' in node.nodeName:
                projectId = nodeID//10
                project = ProjectInfo.objects.get(projectID=projectId)
                project.state='complate'
            project.save()
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1316,"data":"[FUN ERROR] Add new event error in {}".format(current_step)})
        res = {'code':1101,'data':'add event success'}
        log_tools.log_response(res)
        return JsonResponse(res)

# 动态信息 - 形象进度
class Bulletin(View):
    # 获取形象进度 / 查询形象进度
    def get(self,request):
        try:
            token = request.GET.get('token','')
            keyword= request.GET.get('keyword','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token:
            log_tools.log_param_error('查询动态信息',[token])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        log_tools.log_request(user_info['username'],'查询动态信息 - 工程简报',request.GET)
        relations = RelationInfo.objects.filter(userID=user_info['userid'])
        infos = 'none'
        for rela in relations:
            projectId = rela.projectID
            project = ProjectInfo.objects.get(projectID=projectId)
            if project.deleted:
                continue
            infos_single = ScheduleInfo.objects.filter(scheduleID__startswith=projectId,finishState=1)
            if infos=='none':
                infos = infos_single
            else:
                infos = infos | infos_single
        infos = infos.order_by('-finishTime')
        data = []
        for info in infos:
            event,projectID = get_full_info(info,'bulletin')
            if event=='error':
                continue
            if keyword=='' or keyword in event:
                try:
                    project = ProjectInfo.objects.get(projectID=projectID)
                    icons = ImageInfo.objects.filter(mapID=projectID)
                    imgs = ImageInfo.objects.filter(mapID=info.scheduleID)
                except:
                    log_tools.log_error(traceback.format_exc())
                    return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                imgs = [img.imgPath for img in imgs]
                if not imgs:
                    imgs = ["/images/bigevent01.png"]
                event_info = {
                    "eid": str(info.scheduleID),
                    "pIcon": icons[0].imgPath,
                    "pName": project.projectName,
                    "eventMsg": event,
                    "imgList": imgs,
                    "eventTime": get_date(info.finishTime),
                    "completeDate": get_date(info.realFinishTime)
                }
                data.append(event_info)
        res = {'code':1015,'data':data}
        log_tools.log_response(res)
        return JsonResponse(res)

    # 新增形象进度
    def post(self,request):
        try:
            param = json.loads(request.body)
            token = param.get('token','')
            scheduleID = param.get('scheduleID','')
            completedate = param.get('completeDate','')
            imgPath = param.get('imgPath','')
            floor_range = param.get('floorRange','')
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not token or not scheduleID or not imgPath or not completedate:
            log_tools.log_param_error('发布动态信息',[token,scheduleID,imgPath,completedate])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        user_info = get_payload(token)
        if user_info=='error':
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"})
        try:
            scheduleID = int(scheduleID)
        except:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        log_tools.log_request(user_info['username'],'发布动态信息 - 工程简报',param)
        schedule_suffix = scheduleID%1000
        schedule_prefix = scheduleID//1000000
        try:
            floor_min,floor_max = int(floor_range[0]),int(floor_range[1])
            mode='number'
        except:
            floor_min,floor_max = ord(floor_range[0])-ord('a'),ord(floor_range[1])-ord('a')
            mode='alpha'
        for i in range(floor_min,floor_max):
            if i==0:
                continue
            elif i<0:
                scheduleID = (schedule_prefix*1000+200+abs(i))*1000+schedule_suffix
            else:
                if mode=='number':
                    scheduleID = (schedule_prefix*1000+100+abs(i))*1000+schedule_suffix
                else:
                    scheduleID = (schedule_prefix*1000+300+abs(i))*1000+schedule_suffix
            try:
                sch = ScheduleInfo.objects.get(scheduleID=scheduleID)
                module = ModuleInfo.objects.get(moduleID=scheduleID//10)
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
            if sch.finishState==1:
                continue
            try:
                with transaction.atomic():
                    current_step = 'schedule'
                    sch.finishState=1
                    sch.uploadPeople = user_info['userid']
                    sch.finishTime = int(time.strftime('%Y%m%d%H%M',time.localtime(time.time())))
                    sch.realFinishTime = int(completedate.replace('-',''))
                    sch.save()

                    current_step = 'module'
                    finish = module.finishCount
                    finish+=1
                    module.finishCount = finish
                    module.save()

                    current_step = 'img'
                    if imgPath and isinstance(imgPath,list):
                        while True:
                            first = ImageInfo.objects.all().order_by('imgID').last().imgID
                            second = ImageInfo.objects.all().order_by('imgID').last().imgID
                            if first==second:
                                now_max = first
                                break
                        imgID = now_max+1 if now_max!=0 else 100000
                        i = 1
                        for img in imgPath:
                            temp = ImageInfo.objects.create(
                                imgID=imgID+i,
                                imgPath=img,
                                mapID=scheduleID
                            )
                            temp.save()
                            i+=1
            except:
                log_tools.log_error(traceback.format_exc())
                return JsonResponse({"code":1318,"data":"[FUN ERROR] Add new bulletin error in {}".format(current_step)})
        res = {'code':1102,'data':'add bulletin success'}
        log_tools.log_response(res)
        return JsonResponse(res)