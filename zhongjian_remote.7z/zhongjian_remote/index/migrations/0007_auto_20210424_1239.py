# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0006_noticeinfo'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='noticeinfo',
            options={'verbose_name': '项目滚动消息', 'verbose_name_plural': '项目滚动消息'},
        ),
        migrations.AlterModelTable(
            name='noticeinfo',
            table='Notice_Info',
        ),
    ]
