from django.conf.urls import url
from .views import * 

urlpatterns = [
    url(r'^survey$', Survey.as_view()),
    url(r'^notice$', Notice.as_view()),
    url(r'^imgs$', Imgs.as_view()),
    url(r'^framework$', Framework.as_view()),
    url(r'^ModifyDepartments',ModifyDepartments.as_view()),
    url(r'^singlemodel$', SingleModel.as_view()),
    url(r'^planmanager$', PlanManager.as_view()),
    url(r'^schedule$', Schedule.as_view()),
    url(r'^deleteInfo$', DeleteInfo.as_view()),
    url(r'^$', Index.as_view()),
]