source /etc/profile

LOGDIR="./log/"
sourcelogpath="./uwsgi.log"
DATE=`date -d "yesterday" +"%Y%m%d"`
destlogpath="${LOGDIR}uwsgi-${DATE}.log"
cp $sourcelogpath $destlogpath
cat /dev/null > $sourcelogpath

LOGDIR="./log/"
handellogpath='./format_log.log'
DATE=`date -d "yesterday" +"%Y%m%d"`
destlogpath="${LOGDIR}handle-${DATE}.log"
cp $handellogpath $destlogpath
cat /dev/null > $handellogpath

LOGDIR="./log/"
errorlogpath='./error_log.log'
DATE=`date -d "yesterday" +"%Y%m%d"`
destlogpath="${LOGDIR}error-${DATE}.log"
cp $errorlogpath $destlogpath
cat /dev/null > $errorlogpath
