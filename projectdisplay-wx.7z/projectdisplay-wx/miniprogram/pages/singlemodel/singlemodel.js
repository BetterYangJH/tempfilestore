// // pages/singlemodel/singlemodel.js
Page({
  data: {
      use_data: {
        "bid": {
          "bi2": "二标",
          "bi3": "三标"
        },
        "plots": {
          "pl1": { "name": "地块1", "bid": "bi2" },
          "pl2": { "name": "地块2", "bid": "bi2" },
          "pl3": { "name": "地块3", "bid": "bi2" },
          "pl4": { "name": "地块3", "bid": "bi3" },
          "pl5": { "name": "地块3", "bid": "bi3" }
        },
        "paname": {
          "pa1": { "name": "图书馆", "plots": "pl1" },
          "pa2": { "name": "学生服务中心", "plots": "pl1" },
          "pa3": { "name": "医科组团", "plots": "pl2" },
          "pa4": { "name": "西区组团", "plots": "pl3" }
        },
        "build_id": {
          "bu1": { "id": "5#", "floor": "1~10", "resp": "黄志斌", "paname": "pa1" },
          "bu2": { "id": "2#", "floor": "1-3", "resp": "陈彪", "paname": "pa1" },
          "bu3": { "id": "20#", "floor": "-1~9", "resp": "王刚", "paname": "pa1" },
          "bu4": { "id": "A栋", "floor": "-1~6", "resp": "黄元威", "paname": "pa2" },
          "bu5": { "id": "B栋", "floor": "-1~7", "resp": "丘善章", "paname": "pa2" }
        }
      },
      array: ['美国', '中国', '巴西', '日本'],
      // 标段
      section:"",
      // 地段
      district:"",
      // 单体名称
      singlename:"",
      // 具体信息
      detail:[],
      section_index:0,
      district_index:0,
      singlename_index:0,
      
      
    },
  initData:function () {
    var section = []
    var section_id=""
    var singlename=[]
    var detail=[]
    var district=[]
    var singlename=[]
    var tmp_arr1 = []
    var tmp_arr2 = []

    for (var item in this.data.use_data.bid){
      section_id=item
      tmp_arr1[tmp_arr1.length] = item
      tmp_arr2[tmp_arr2.length] = this.data.use_data.bid[item]
    }
    section=[tmp_arr1,tmp_arr2]

    tmp_arr1 = []
    tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
      // section_id = item
      if ("bi2" == this.data.use_data.plots[item].bid) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
      }
    }
    district = [tmp_arr1, tmp_arr2]



    // tmp_arr1 = []
    // tmp_arr2 = []
    // for (var item in this.data.use_data.paname) {
    //   if ("pl1" == this.data.use_data.paname[item].plots) {
    //     console.log(item)
    //     tmp_arr1[tmp_arr1.length] = item
    //     tmp_arr2[tmp_arr2.length] = this.data.use_data.paname[item].name
    //   }
    // }
    // singlename = [tmp_arr1, tmp_arr2]


    // for (var item in this.data.use_data.build_id) {
    //   if ("pa1" == this.data.use_data.build_id[item].paname) {
    //     console.log(item)
    //     detail[detail.length] = this.data.use_data.build_id[item]
    //   }
    // }
    for (var item in this.data.use_data.paname) {
      if ("pl1" == this.data.use_data.paname[item].plots) {
        var tmp_dict = {}
        tmp_dict["name"] = this.data.use_data.paname[item].name
        console.log(this.data.use_data.paname[item].name)
        var msg_list = []
        for (var j in this.data.use_data.build_id) {
          if (item == this.data.use_data.build_id[j].paname) {
            msg_list[msg_list.length] = this.data.use_data.build_id[j]
          }
        }
        tmp_dict["msg"] = msg_list
        singlename[singlename.length] = tmp_dict
      }
    }


    console.log(section)
    this.setData({
      section:section,
      district: district,
      singlename: singlename,
      detail: detail
  })
},

  bindPickerChange_section: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
      var district = []
    var section_index = ""
      var vur_id= this.data.section[0][e.detail.value]
      var tmp_arr1 = []
      var tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
        // section_id = item
      if (vur_id == this.data.use_data.plots[item].bid){
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
       }
      }
    district = [tmp_arr1, tmp_arr2]

    console.log(district)
      this.setData({
        district: district,
        section_index: e.detail.value,
        district_index:0
      })
    },

  bindPickerChange_district: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var vur_id = this.data.district[0][e.detail.value]
    console.log(vur_id)
    var singlename = []
    for (var item in this.data.use_data.paname) {
      if (vur_id == this.data.use_data.paname[item].plots) {
        var tmp_dict = {}
        tmp_dict["name"] = this.data.use_data.paname[item].name
        console.log(this.data.use_data.paname[item].name)
        var msg_list = []
        for (var j in this.data.use_data.build_id){
          if (item == this.data.use_data.build_id[j].paname) {
            msg_list[msg_list.length] = this.data.use_data.build_id[j]
          }
        }
        tmp_dict["msg"] = msg_list
        singlename[singlename.length] = tmp_dict
      }
    }
    console.log(singlename,"-----------------")
    this.setData({
      singlename: singlename,
      district_index: e.detail.value,
      singlename_index:0
    })
  },
  // bindPickerChange_singlename: function (e) {
  //   console.log('picker发送选择改变，携带值为', e.detail.value)
  //   var vur_id = this.data.singlename[0][e.detail.value]
  //   var detail  = []
  //   console.log(vur_id)
  //   for (var item in this.data.use_data.build_id){
  //     if (vur_id == this.data.use_data.build_id[item].paname){
  //       console.log(item)
  //       detail[detail.length] = this.data.use_data.build_id[item]
  //     }
  //   }
  //   this.setData({
  //     detail: detail,
  //     singlename_index: e.detail.value

  //   })

  // },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.initData()
  },
})
