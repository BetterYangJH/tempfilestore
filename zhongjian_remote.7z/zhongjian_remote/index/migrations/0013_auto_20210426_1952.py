# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0012_auto_20210425_1154'),
    ]

    operations = [
        migrations.AddField(
            model_name='scheduleinfo',
            name='realFinishTime',
            field=models.IntegerField(verbose_name='实际完成时间', null=True),
        ),
        migrations.AlterField(
            model_name='scheduleinfo',
            name='finishTime',
            field=models.IntegerField(verbose_name='提交时间', null=True),
        ),
    ]
