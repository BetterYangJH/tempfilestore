// pages/addEvent/addevent.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    countPic: 9,//上传图片最大数量
    showImgUrl: "", //路径拼接，一般上传返回的都是文件名，
    uploadImgUrl: '',//图片的上传的路径
    detailPics:[],
    count:9,
    // 当前用户绑定的项目
    project: ["项目A", "项目B", "项目C"],
    projectIndex: 0,
    selectProject:"",

    // 当前项目的阶段
    stage: ["A", "B", "C"],
    stageIndex: 0,
    selectStage:""
  },
  // //监听组件事件，返回的结果
  // myEventListener: function (e) {
  //   console.log("上传的图片结果集合")
  //   console.log(e.detail.picsList)
  // },

  /**
   * 上传详细图片
   */
uploadDetailImage: function (e) { //这里是选取图片的方法
  var that = this;
  var pics = [];
  var timestamp = Date.parse(new Date());
  var detailPics = that.data.detailPics;
  if (detailPics.length >= that.data.count) {
    wx.showToast({
      title: '最多选择' + that.data.count + '张！',
    })
    return;
  }
  wx.chooseImage({
    count: that.data.count, // 最多可以选择的图片张数，默认9
    sizeType: ['original', 'compressed'], // original 原图，compressed 压缩图，默认二者都有
    sourceType: ['album', 'camera'], // album 从相册选图，camera 使用相机，默认二者都有
    success: function (res) {
      var imgs = res.tempFilePaths;
      for (var i = 0; i < imgs.length; i++) {
        pics.push(imgs[i])
      }
      // console.log(pics)
      that.uploadimg({
        // url: that.data.uploadUrl, //这里是你图片上传的接口
        path: pics, //这里是选取的图片的地址数组
      });
    },
  })
},
//多张图片上传
uploadimg: function (data) {
  console.log(data.path)

  // var img_list
  // var add_mes = [{
  //   // id: this.data.imgs_list.length,
  //   img: data.pics,
  //   user_name: name,
  //   time: timestamp,
  //   icon: icon,
  //   flag: true
  // }]
  // console.log(add_mes)
  // wx.setStorageSync('img_list', add_mes)
  var detailPics = this.data.detailPics.concat(data.path)
  // detailPics.concat(data.path)
  console.log(detailPics)
  this.setData({
    detailPics:detailPics
  })
// wx.showLoading({
//   title: '上传中...',
//   mask: true,
// })
// var that = this,
//   i = data.i ? data.i : 0,
//   success = data.success ? data.success : 0,
//   fail = data.fail ? data.fail : 0;
//   console.log(i)
// wx.uploadFile({
//   url: data.url,
//   filePath: data.path[i],
//   name: 'fileData',
//   formData: null,
//   success: (resp) => {
//     wx.hideLoading();
//     success++;
//     var str = resp.data //返回的结果，可能不同项目结果不一样
//     var pic = JSON.parse(str);
//     var pic_name = that.data.showUrl + pic.Data;
//     var detailPics = that.data.detailPics;
//     detailPics.push(pic_name)
//     that.setData({
//       detailPics: detailPics
//     })
//   },
//   fail: (res) => {
//     fail++;
//     console.log('fail:' + i + "fail:" + fail);
//   },
//   complete: () => {
//     i++;
//     if (i == data.path.length) { //当图片传完时，停止调用     
//       console.log('执行完毕');
//       console.log('成功：' + success + " 失败：" + fail);
//       var myEventDetail = {
//         picsList: that.data.detailPics
//       } // detail对象，提供给事件监听函数
//       var myEventOption = {} // 触发事件的选项
//       that.triggerEvent('myevent', myEventDetail, myEventOption)
//     } else { //若图片还没有传完，则继续调用函数
//       data.i = i;
//       data.success = success;
//       data.fail = fail;
//       that.uploadimg(data);
//     }
//   }
// });
  },

  bindprojectChange:function (e) {
    // console.log(e)
    var index = e.detail.value
    this.setData({
      projectIndex:index,
      selectProject:this.data.project[index]
    })
  },
  bindstageChange:function (e) {
    // console.log(e)
    var index = e.detail.value
    this.setData({
      stageIndex: index,
      selectStage: this.data.stage[index]
    })
  },

submit:function (e) {
  console.log("-----")
  var userInfo = wx.getStorageSync('userinfo')
  var name = userInfo.nickName
  var icon = userInfo.avatarUrl
  var timestamp = Date.parse(new Date());
  var Dates = new Date();
  var year = Dates.getFullYear();
  var mouth = Dates.getMonth();
  var day = Dates.getDate();
  var hours = Dates.getHours();
  var minu = Dates.getMinutes();
  var sec = Dates.getSeconds()
  var date = year + "." + mouth + "." + day + " " + hours+":"+minu +":"+sec
  // console.log(timestamp.getFullYear())
  var currentProject = this.data.selectProject
  var currentStage = this.data.selectStage
  if (currentProject==""){
    currentProject = this.data.project[0]
    console.log("==============")
  }
  if (currentStage==""){
    currentStage = this.data.stage[0]
  }
    var add_mes = [{
      id: date,
    icon: icon,
    img: this.data.detailPics,
    user_name: name,
      currentProject: currentProject,
      currentStage: currentStage,
      time: date,
    flag: true
  }]
  console.log(add_mes)
  var old_mes = wx.getStorageSync('addevent')
  if(old_mes == ""){
    old_mes=[]
  }
  wx.setStorageSync('addevent', old_mes.concat(add_mes))
  wx.switchTab({
    url: '/pages/bigEvent/index',
  })
},












  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})