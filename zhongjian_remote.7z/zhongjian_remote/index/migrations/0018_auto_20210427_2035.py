# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0017_auto_20210427_2007'),
    ]

    operations = [
        migrations.RenameField(
            model_name='phaseinfo',
            old_name='singelID',
            new_name='singleID',
        ),
    ]
