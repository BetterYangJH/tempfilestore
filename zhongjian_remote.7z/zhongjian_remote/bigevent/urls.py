from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^bigevent$', views.BigEvent.as_view()),
    url(r'^bulletin$', views.Bulletin.as_view()),
]