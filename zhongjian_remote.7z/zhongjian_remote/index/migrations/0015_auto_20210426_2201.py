# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0014_projectinfo_permitdate'),
    ]

    operations = [
        migrations.AlterField(
            model_name='blockinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='buildinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='floorinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='imageinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='moduleinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='nodeinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='noticeinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='phaseinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='continueDate',
            field=models.IntegerField(verbose_name='竣工顺延日期', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='permitDate',
            field=models.IntegerField(verbose_name='施工许可证日期', null=True),
        ),
        migrations.AlterField(
            model_name='projectinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='relationinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='scheduleinfo',
            name='finishTime',
            field=models.BigIntegerField(verbose_name='提交时间', null=True),
        ),
        migrations.AlterField(
            model_name='scheduleinfo',
            name='realFinishTime',
            field=models.BigIntegerField(verbose_name='实际完成时间', null=True),
        ),
        migrations.AlterField(
            model_name='scheduleinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='segmentinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='singleinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
        migrations.AlterField(
            model_name='unitsinfo',
            name='updateData',
            field=models.DateTimeField(verbose_name='数据最新修改时间', db_index=True, default=django.utils.timezone.now),
        ),
    ]
