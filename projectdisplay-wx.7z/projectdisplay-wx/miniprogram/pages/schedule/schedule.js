// // pages/singlemodel/singlemodel.js
Page({
  data: {
    use_data: {
      "bid": {
        "bi2": "二标",
        "bi3": "三标"
      },
      "plots": {
        "pl1": { "name": "地块1", "bid": "bi2" },
        "pl2": { "name": "地块2", "bid": "bi2" },
        "pl3": { "name": "地块3", "bid": "bi2" },
        "pl4": { "name": "地块3", "bid": "bi3" },
        "pl5": { "name": "地块3", "bid": "bi3" }
      },
      "paname": {
        "pa1": { "name": "图书馆", "plots": "pl1" },
        "pa2": { "name": "学生服务中心", "plots": "pl1" },
        "pa3": { "name": "医科组团", "plots": "pl2" },
        "pa4": { "name": "西区组团", "plots": "pl3" }
      },
      "build_id": {
        "bu1": { "name": "5#", "paname": "pa1" },
        "bu2": { "name": "2#", "paname": "pa1" },
        "bu3": { "name": "20#", "paname": "pa1" },
        "bu4": { "name": "A栋", "paname": "pa1" },
        "bu5": { "name": "B栋", "paname": "pa1" }
      },
      "schedule":{
        "sc1": { "floor": [-1, 1, 2, 3, 4, 5], "cur_sch": [1, 0, 0, 0, 0, 0], "project_id": ["pro1", "pro2", "pro3", "pro4", "pro5", "pro6"],"build_id":"bu1"}
      }
    },
    // 标段
    section: "",
    // 地段
    district: "",
    // 单体名称
    singlename: "",
    // 栋号、区号
    building:"",
    // 具体信息
    detail: [],
    section_index: 0,
    district_index: 0,
    singlename_index: 0,
    building_index:0


  },
  initData: function () {
    var section = []
    var section_id = ""
    var singlename = []
    var detail = []
    var district = []
    var singlename = []
    var building = []
    var tmp_arr1 = []
    var tmp_arr2 = []

    for (var item in this.data.use_data.bid) {
      section_id = item
      tmp_arr1[tmp_arr1.length] = item
      tmp_arr2[tmp_arr2.length] = this.data.use_data.bid[item]
    }
    section = [tmp_arr1, tmp_arr2]

    tmp_arr1 = []
    tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
      // section_id = item
      if ("bi2" == this.data.use_data.plots[item].bid) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
      }
    }
    district = [tmp_arr1, tmp_arr2]

    tmp_arr1 = []
    tmp_arr2 = []
    for (var item in this.data.use_data.paname) {
      if ("pl1" == this.data.use_data.paname[item].plots) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.paname[item].name
      }
    }
    singlename = [tmp_arr1, tmp_arr2]

    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.build_id) {
      if ("pa1" == this.data.use_data.build_id[item].paname) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.build_id[item].name
      }
    }
    building = [tmp_arr1, tmp_arr2]

    for (var item in this.data.use_data.schedule) {
      if ("bu1" == this.data.use_data.schedule[item].build_id) {
        detail = this.data.use_data.schedule[item]
      }
    }
    console.log(detail)
    this.setData({
      section: section,
      district: district,
      singlename: singlename,
      building:building,
      detail: detail
    })
  },

  bindPickerChange_section: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var district = []
    var section_index = ""
    var vur_id = this.data.section[0][e.detail.value]
    var tmp_arr1 = []
    var tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
      // section_id = item
      if (vur_id == this.data.use_data.plots[item].bid) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
      }
    }
    district = [tmp_arr1, tmp_arr2]

    console.log(district)
    this.setData({
      district: district,
      section_index: e.detail.value,
      district_index: 0
    })
  },

  bindPickerChange_district: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var singlename = []
    var district_index = ""
    var vur_id = this.data.district[0][e.detail.value]
    console.log(vur_id)
    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.paname) {
      if (vur_id == this.data.use_data.paname[item].plots) {
        console.log(item)
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.paname[item].name
      }
    }
    singlename = [tmp_arr1, tmp_arr2]

    console.log(singlename)
    this.setData({
      singlename: singlename,
      district_index: e.detail.value,
      singlename_index: 0
    })
  },

  bindPickerChange_singlename: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    console.log(this.data.singlename)
    var vur_id = this.data.singlename[0][e.detail.value]
    var building = []
    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.build_id) {
      if (vur_id == this.data.use_data.build_id[item].paname) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.build_id[item].name
      }
    }
    building = [tmp_arr1, tmp_arr2]
    console.log(building)
    this.setData({
      building: building,
      singlename_index: e.detail.value,
      building_index:0

    })
    
  },
  
  bindPickerChange_build:function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var vur_id = this.data.building[0][e.detail.value]
    var detail=""
    console.log(vur_id)
    for (var item in this.data.use_data.schedule) {
      if (vur_id == this.data.use_data.schedule[item].build_id) {
        console.log(item)
        // building[building.length] = this.data.use_data.build_id[item]
        detail = this.data.use_data.build_id[item]
      }
    }
    this.setData({
      detail: detail,
      building_index: e.detail.value
    })
  },
  
  // 点击对应的进度跳转大事件页面
  showevent:function(e) {
    console.log(e.currentTarget.dataset.projectid)
    var projectid = e.currentTarget.dataset.projectid
    wx.navigateTo({
      url: '/pages/wrokbulletin/wrokbulletin?pro_id=' + projectid,
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.initData()
  },
})
