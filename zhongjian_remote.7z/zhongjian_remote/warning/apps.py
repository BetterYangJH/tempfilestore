from django.apps import AppConfig


class WarningConfig(AppConfig):
    name = 'warning'
