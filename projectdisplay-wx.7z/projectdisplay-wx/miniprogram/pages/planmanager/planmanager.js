// pages/planmanager/planmanager.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // scroll_data:[
    //   { "event": "办公区临设工程完成", "needtime": "2018.8.5", "complate_time": "2018.8.4" },
    //   { "event": "工友村临设工程完成", "needtime": "2018.8.6", "complate_time": "" },
    //   { "event": "围挡封闭完成", "needtime": "2018.8.10", "complate_time": "" },
    //   { "event": "现场三通一平完成", "needtime": "2018.8.20", "complate_time": "" },
    //   { "event": "基坑支护完成", "needtime": "2018.12.1", "complate_time": "2018.12.2"},
    //   { "event": "基坑开挖完成", "needtime": "2019.1.20", "complate_time": "" },
    //   { "event": "基础施工完成", "needtime": "2019.3.15", "complate_time": "" },
    //   { "event": "底板浇筑完成", "needtime": "2019.4.1", "complate_time": "" },
    //   { "event": "地下室封顶", "needtime": "2019.10.11", "complate_time": "" },
    //   { "event": "主体封顶", "needtime": "2019.12.29", "complate_time": "" },
    //   { "event": "屋面构筑物完成", "needtime": "2020.1.13", "complate_time": "" },
    //   { "event": "二次结构完成", "needtime": "2020.5.20", "complate_time": "" },
    //   { "event": "高低压通电", "needtime": "2020.7.2", "complate_time": "" },
    //   { "event": "排水验收", "needtime": "2020.7.10", "complate_time": "" },
    //   { "event": "给水接驳", "needtime": "2020.7.12", "complate_time": "" },
    //   { "event": "人防验收", "needtime": "2020.8.5", "complate_time": "" },
    //   { "event": "电梯验收", "needtime": "2020.8.14", "complate_time": "" },
    //   { "event": "燃气验收", "needtime": "2020.8.31", "complate_time": "" },
    //   { "event": "消防验收", "needtime": "2020.8.31", "complate_time": "" },
    //   { "event": "防雷验收", "needtime": "2020.8.9", "complate_time": "" },
    //   { "event": "节能验收", "needtime": "2020.8.14", "complate_time": "" },
    //   { "event": "环保验收", "needtime": "2020.8.14", "complate_time": "" },
    //   { "event": "水土保持验收", "needtime": "2020.8.14", "complate_time": "" },
    //   { "event": "规划验收", "needtime": "2020.8.6", "complate_time": "" },
    //   { "event": "档案验收", "needtime": "2020.8.30", "complate_time": "" },
    //   { "event": "竣工验收", "needtime": "2020.9.1", "complate_time": "2020.9.10" },
    //   { "event": "竣工备案", "needtime": "2020.9.20", "complate_time": "" },
    // ],

    personList: [
      {
        id: 0,
        sign: "施工准备",
        name:[
          { "event": "办公区临设工程完成", "needtime": "2018.8.5", "complate_time": "2018.8.4" },
          { "event": "工友村临设工程完成", "needtime": "2018.8.6", "complate_time": "" },
          { "event": "围挡封闭完成", "needtime": "2018.8.10", "complate_time": "" },
          { "event": "现场三通一平完成", "needtime": "2018.8.20", "complate_time": "" },
        ]
      },
      {
        id: 1,
        sign: "在建施工",
        name:[
          { "event": "基坑支护完成", "needtime": "2018.12.1", "complate_time": "2018.12.2" },
          { "event": "基坑开挖完成", "needtime": "2019.1.20", "complate_time": "" },
          { "event": "基础施工完成", "needtime": "2019.3.15", "complate_time": "" },
          { "event": "底板浇筑完成", "needtime": "2019.4.1", "complate_time": "" },
          { "event": "地下室封顶", "needtime": "2019.10.11", "complate_time": "" },
          { "event": "主体封顶", "needtime": "2019.12.29", "complate_time": "" },
          { "event": "屋面构筑物完成", "needtime": "2020.1.13", "complate_time": "" },
          { "event": "二次结构完成", "needtime": "2020.5.20", "complate_time": "" },
        ]
      },
      {
        id: 2,
        sign: "专项验收",
        // name: [{ name: "a阿拉善盟C" }, { name: "Cappless" }, { name: "Capplyss" }]
        name:[
          { "event": "高低压通电", "needtime": "2020.7.2", "complate_time": "" },
          { "event": "排水验收", "needtime": "2020.7.10", "complate_time": "" },
          { "event": "给水接驳", "needtime": "2020.7.12", "complate_time": "" },
          { "event": "人防验收", "needtime": "2020.8.5", "complate_time": "" },
          { "event": "电梯验收", "needtime": "2020.8.14", "complate_time": "" },
          { "event": "燃气验收", "needtime": "2020.8.31", "complate_time": "" },
          { "event": "消防验收", "needtime": "2020.8.31", "complate_time": "" },
          { "event": "防雷验收", "needtime": "2020.8.9", "complate_time": "" },
          { "event": "节能验收", "needtime": "2020.8.14", "complate_time": "" },
          { "event": "环保验收", "needtime": "2020.8.14", "complate_time": "" },
          { "event": "水土保持验收", "needtime": "2020.8.14", "complate_time": "" },
          { "event": "规划验收", "needtime": "2020.8.6", "complate_time": "" },
          { "event": "档案验收", "needtime": "2020.8.30", "complate_time": "" },
          { "event": "竣工验收", "needtime": "2020.9.1", "complate_time": "2020.9.10" },
          { "event": "竣工备案", "needtime": "2020.9.20", "complate_time": "" },
        ]
      }
    ],
    oHeight: '',
    // 四级选择菜单数据
    use_data: {
      "bid": {
        "bi2": "二标",
        "bi3": "三标"
      },
      "plots": {
        "pl1": { "name": "地块1", "bid": "bi2" },
        "pl2": { "name": "地块2", "bid": "bi2" },
        "pl3": { "name": "地块3", "bid": "bi2" },
        "pl4": { "name": "地块3", "bid": "bi3" },
        "pl5": { "name": "地块3", "bid": "bi3" }
      },
      "paname": {
        "pa1": { "name": "图书馆", "plots": "pl1" },
        "pa2": { "name": "学生服务中心", "plots": "pl1" },
        "pa3": { "name": "医科组团", "plots": "pl2" },
        "pa4": { "name": "西区组团", "plots": "pl3" }
      },
      "build_id": {
        "bu1": { "name": "5#", "paname": "pa1" },
        "bu2": { "name": "2#", "paname": "pa1" },
        "bu3": { "name": "20#", "paname": "pa1" },
        "bu4": { "name": "A栋", "paname": "pa1" },
        "bu5": { "name": "B栋", "paname": "pa1" }
      },
      "schedule": {
        "sc1": { "floor": [-1, 1, 2, 3, 4, 5], "cur_sch": [1, 0, 0, 0, 0, 0], "build_id": "bu1" }
      }
    },
    array: ['美国', '中国', '巴西', '本'],
    // 标段
    section: "",
    // 地段
    district: "",
    // 单体名称
    singlename: "",
    // 栋号、区号
    building: "",
    // 具体信息
    detail: [],
    section_index: 0,
    district_index: 0,
    singlename_index: 0,
    building_index: 0,
    changed_mes:[],
    dialogShow:false



  },

  // 排序
  listSort(prop) {
    return function (a, b) {
      var value1 = a[prop].charCodeAt();
      var value2 = b[prop].charCodeAt();
      return value1 - value2
    }
  },
  // 点击列表中的人员
  choose(e) {
    console.log(e.currentTarget.dataset.item)
    let name = e.currentTarget.dataset.item.name
    wx.showToast({
      title: name,
      icon: 'none'
    })
  },
  /**
   * 点击右侧字母
   * 这里使用的是scroll-view中的自身方法,在scroll-view中添加以下属性
   * 1、enable-back-to-top,点击标题回弹
   * 2、scroll-into-view="{{toView}}",滚动到id为toView的位置,动态设置该id即起到切换的左右
   * 3、scroll-y="true",y轴方向滚动
   * 4、scroll-with-animation="true",滚动动画
   * 注:在使用scroll-view时:必须给当前盒子设置固定的高度,否则无法生效
   */
  chooseLetter(e) {
    let currentItem = e.currentTarget.dataset.item
    this.data.personList.forEach(item => {
      if (item.sign == currentItem.sign) {
        this.setData({
          toView: 'inToView' + currentItem.id, //滚动条to指定view
        })
      }
    })
  },

// 四级选择框需要的函数，从时间进度拷贝，后期需要修改detail中的数据
  initData: function () {
    var section = []
    var section_id = ""
    var singlename = []
    var detail = []
    var district = []
    var singlename = []
    var building = []
    var tmp_arr1 = []
    var tmp_arr2 = []

    for (var item in this.data.use_data.bid) {
      section_id = item
      tmp_arr1[tmp_arr1.length] = item
      tmp_arr2[tmp_arr2.length] = this.data.use_data.bid[item]
    }
    section = [tmp_arr1, tmp_arr2]

    tmp_arr1 = []
    tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
      // section_id = item
      if ("bi2" == this.data.use_data.plots[item].bid) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
      }
    }
    district = [tmp_arr1, tmp_arr2]

    tmp_arr1 = []
    tmp_arr2 = []
    for (var item in this.data.use_data.paname) {
      if ("pl1" == this.data.use_data.paname[item].plots) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.paname[item].name
      }
    }
    singlename = [tmp_arr1, tmp_arr2]

    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.build_id) {
      if ("pa1" == this.data.use_data.build_id[item].paname) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.build_id[item].name
      }
    }
    building = [tmp_arr1, tmp_arr2]

    for (var item in this.data.use_data.schedule) {
      if ("bu1" == this.data.use_data.schedule[item].build_id) {
        detail = this.data.use_data.schedule[item]
      }
    }
    console.log(detail)
    this.setData({
      section: section,
      district: district,
      singlename: singlename,
      building: building,
      detail: detail
    })
  },

  bindPickerChange_section: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var district = []
    var section_index = ""
    var vur_id = this.data.section[0][e.detail.value]
    var tmp_arr1 = []
    var tmp_arr2 = []

    for (var item in this.data.use_data.plots) {
      // section_id = item
      if (vur_id == this.data.use_data.plots[item].bid) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.plots[item].name
      }
    }
    district = [tmp_arr1, tmp_arr2]

    console.log(district)
    this.setData({
      district: district,
      section_index: e.detail.value,
      district_index: 0
    })
  },
  bindPickerChange_district: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var singlename = []
    var district_index = ""
    var vur_id = this.data.district[0][e.detail.value]
    console.log(vur_id)
    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.paname) {
      if (vur_id == this.data.use_data.paname[item].plots) {
        console.log(item)
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.paname[item].name
      }
    }
    singlename = [tmp_arr1, tmp_arr2]

    console.log(singlename)
    this.setData({
      singlename: singlename,
      district_index: e.detail.value,
      singlename_index: 0
    })
  },

  bindPickerChange_singlename: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    console.log(this.data.singlename)
    var vur_id = this.data.singlename[0][e.detail.value]
    var building = []
    var tmp_arr1 = []
    var tmp_arr2 = []
    for (var item in this.data.use_data.build_id) {
      if (vur_id == this.data.use_data.build_id[item].paname) {
        tmp_arr1[tmp_arr1.length] = item
        tmp_arr2[tmp_arr2.length] = this.data.use_data.build_id[item].name
      }
    }
    building = [tmp_arr1, tmp_arr2]
    console.log(building)
    this.setData({
      building: building,
      singlename_index: e.detail.value,
      building_index: 0

    })

  },

  bindPickerChange_build: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var vur_id = this.data.building[0][e.detail.value]
    var detail = ""
    console.log(vur_id)
    for (var item in this.data.use_data.schedule) {
      if (vur_id == this.data.use_data.schedule[item].build_id) {
        console.log(item)
        // building[building.length] = this.data.use_data.build_id[item]
        detail = this.data.use_data.build_id[item]
      }
    }
    this.setData({
      detail: detail,
      building_index: e.detail.value
    })
  },

  //点击我显示底部弹出框
  changetime: function (e) {
    this.showModal();
    this.setData({
      changed_mes: [e.currentTarget.dataset.id,e.currentTarget.dataset.index, e.currentTarget.dataset.place]
    })
  },

  //显示对话框
  showModal: function () {
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
// 显示基础信息弹窗
showdialog:function(){
this.setData({
  dialogShow:true
})
},
  handleSelectDate:function (e) {
    // console.log(e.detail.date)
    var tmp_change_date = e.detail.date
    tmp_change_date = tmp_change_date.replace(/-/g, ".")
    // console.log(tmp_change_date)
    var tmp = this.data.personList
    tmp[this.data.changed_mes[0]].name[this.data.changed_mes[1]][this.data.changed_mes[2]] = tmp_change_date
    // console.log(tmp)
    this.setData({
      personList:tmp
    })
    this.hideModal()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    // 获取设备高度
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          oHeight: res.windowHeight
        })
      }
    })
    console.log(this.data.personList)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.initData()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})