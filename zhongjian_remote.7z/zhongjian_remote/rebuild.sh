python3.6 manage.py migrate
python3.6 initdb.py
python3.6 add_info.py