from django.db import models
from index.models import BaseModel
# Create your models here.
class UserInfo(BaseModel):
    """
    人员概况
    """
    No = models.IntegerField(verbose_name="人员编号", null=False, unique=True, primary_key=True)
    secretID = models.CharField(verbose_name="小程序编号", null=True, unique=True, db_index=True,max_length=40,default=0)
    userID = models.CharField(verbose_name="工号", null=True, unique=True,max_length=20,default=None)
    userName = models.CharField(verbose_name='姓名', null=False, db_index=True,max_length=10)
    tel = models.CharField(verbose_name="电话", null=False, max_length=14)
    departmentID = models.IntegerField(verbose_name='部门编号', null=False, db_index=True, default=100000)
    positionID = models.IntegerField(verbose_name='职务编号', null=False, default=10000000)
    rightLevel = models.IntegerField(verbose_name="权限级别", null=False, default=0)
    class Meta:
        db_table = 'USER_INFO'
        verbose_name = '人员概况'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.userID)+' - '+self.userName
    
class PositionInfo(BaseModel):
    """
    职务对应表
    """
    positionID = models.IntegerField(verbose_name='职务编号', null=False, unique=True, db_index=True, primary_key=True)
    positionName = models.CharField(verbose_name='职务名称', null=False,max_length=10)
    class Meta:
        db_table = 'POSITION_INFO'
        verbose_name = '职务对应表'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.positionID)+' - '+self.positionName

class DepartmentInfo(BaseModel):
    """
    部门对应表
    """
    departmentID = models.IntegerField(verbose_name='部门编号', null=False, unique=True, db_index=True, primary_key=True)
    departmentName = models.CharField(verbose_name='部门名称', null=False,max_length=10)
    projectID = models.IntegerField(verbose_name='项目编号', null=False, db_index=True)
    standard = models.IntegerField(verbose_name='标配人数', null=False, db_index=True)
    class Meta:
        db_table = 'DEPARTMENT_INFO'
        verbose_name = '部门对应表'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.projectID)+' - '+str(self.departmentID)+' - '+self.departmentName