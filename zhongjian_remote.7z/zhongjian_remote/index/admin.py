from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(ProjectInfo)
class ProjectInfoAdmin(admin.ModelAdmin):
    list_display = ['projectID', 'projectName','projectFormats','barea','carea','amount','duration','conUnit','supUnit','advUnit','surUnit','desUnit','conCommDate','conCompDate','continueDate','awarDate','commDate','permitDate','state','deleted','insertData','updateData']
    list_filter  = ['updateData','duration']
    list_per_page = 20
    ordering = ('updateData','continueDate','permitDate')
    search_fields = ('projectName','conUnit','supUnit','advUnit','surUnit','desUnit','updateData','permitDate')

@admin.register(NoticeInfo)
class NoticeInfoAdmin(admin.ModelAdmin):
    list_display = ['noticeID', 'noticeMsg','projectID','updateData']
    list_filter  = ['noticeID','projectID']
    list_per_page = 20
    ordering = ('noticeID','updateData',)
    search_fields = ('noticeID','noticeMsg','projectID')

@admin.register(UnitsInfo)
class UnitsInfoAdmin(admin.ModelAdmin):
    list_display = ['unitsID', 'unitsName','contect','tel','insertData','updateData']
    list_per_page = 20
    ordering = ('unitsID','updateData')
    search_fields = ('unitsName','contect','updateData')

@admin.register(RelationInfo)
class RelationInfoAdmin(admin.ModelAdmin):
    list_display = ['relationID', 'userID','projectID','insertData','updateData']
    list_filter  = ['userID','projectID']
    list_per_page = 20
    ordering = ('userID','projectID','updateData')
    search_fields = ('userID','projectID','updateData')

@admin.register(ImageInfo)
class ImageInfoAdmin(admin.ModelAdmin):
    list_display = ['imgID', 'imgPath','mapID','insertData','updateData']
    list_per_page = 20
    ordering = ('mapID','imgID','updateData')
    search_fields = ('mapID','updateData')

# 单体模块
@admin.register(SegmentInfo)
class SegmentInfoAdmin(admin.ModelAdmin):
    list_display = ['segmentID', 'segmentName','projectID','insertData','updateData']
    list_filter  = ['projectID',]
    list_per_page = 20
    ordering = ('segmentID','updateData')
    search_fields = ('segmentID','projectID','updateData')

@admin.register(BlockInfo)
class BlockInfoAdmin(admin.ModelAdmin):
    list_display = ['blockID', 'blockName','segmentID','insertData','updateData']
    list_filter  = ['segmentID',]
    list_per_page = 20
    ordering = ('segmentID','updateData')
    search_fields = ('blockID','segmentID','updateData')

@admin.register(SingleInfo)
class SingleInfoAdmin(admin.ModelAdmin):
    list_display = ['singleID', 'singleName','blockID','insertData','updateData']
    list_filter  = ['blockID',]
    list_per_page = 20
    ordering = ('blockID','updateData')
    search_fields = ('singleID','blockID','updateData')

@admin.register(BuildInfo)
class BuildInfoAdmin(admin.ModelAdmin):
    list_display = ['buildID', 'buildName','respID','singleID','insertData','updateData']
    list_filter  = ['respID',]
    list_per_page = 20
    ordering = ('respID','singleID','updateData')
    search_fields = ('buildID','respID','singleID','updateData')

# 计划管理
@admin.register(PhaseInfo)
class PhaseInfoAdmin(admin.ModelAdmin):
    list_display = ['phaseID', 'phaseName','singleID','insertData','updateData']
    list_filter  = ['singleID',]
    list_per_page = 20
    ordering = ('singleID','updateData')
    search_fields = ('phaseID','singleID','updateData')

@admin.register(NodeInfo)
class NodeInfoAdmin(admin.ModelAdmin):
    list_display = ['nodeID', 'nodeName','uploadPeople','right','deadline','finishState','phaseID','finishTime','insertData','updateData']
    list_filter  = ['finishState','phaseID','finishTime','right']
    list_per_page = 20
    ordering = ('nodeID','deadline','updateData','finishTime')
    search_fields = ('nodeID','nodeName','updateData','finishState','phaseID','uploadPeople')

# 形象进度
@admin.register(FloorInfo)
class FloorInfoAdmin(admin.ModelAdmin):
    list_display = ['floorID', 'floorNum','buildID','insertData','updateData']
    list_filter  = ['buildID']
    list_per_page = 20
    ordering = ('floorNum','updateData')
    search_fields = ('floorID','buildID','updateData')

@admin.register(ModuleInfo)
class ModuleInfoAdmin(admin.ModelAdmin):
    list_display = ['moduleID', 'moduleName','floorID','finishCount','total','finishiTag','insertData','updateData']
    list_filter  = ['floorID','total','finishiTag']
    list_per_page = 20
    ordering = ('moduleName','updateData','total','finishiTag')
    search_fields = ('moduleID','moduleName','floorID','total','updateData','finishiTag')

@admin.register(ScheduleInfo)
class ScheduleInfoAdmin(admin.ModelAdmin):
    list_display = ['scheduleID', 'scheduleName','uploadPeople','finishState','moduleID','finishTime','realFinishTime','insertData','updateData']
    list_filter  = ['moduleID','finishState','finishTime','realFinishTime']
    list_per_page = 20
    ordering = ('scheduleName','updateData','finishTime','realFinishTime')
    search_fields = ('scheduleName','moduleID','updateData','uploadPeople')
