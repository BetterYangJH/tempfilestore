
import datetime
import calendar
import traceback
from zhongjian_back.settings import COLORS
from django.views.generic import View
from django.http import JsonResponse
from index.models import NodeInfo
from tools.get_info import *
from tools.token_tools import get_payload
from tools import log_tools

# 获取指定格式当天日期
def get_today():
    today = datetime.datetime.today()
    year, month, day = today.year, today.month, today.day
    return "{}.{}.{}".format(year,month,day)

# 按月获取节点信息
class Warning(View):
    def get(self,request):
        # 获取的数据
        try:
            token = request.GET.get("token","")
            year = request.GET.get("year","")
            month = request.GET.get("month","")
            day = request.GET.get("day","")
        except Exception as e:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1301,"data":"ERROR: Args error"})
        if not year or not month or not day or not token:
            log_tools.log_param_error('获取工程预警信息',[year,month,day,token])
            return JsonResponse({"code":1301,"data":"ERROR: Args error"}) 
        user_info = get_payload(token)
        if user_info=='error':
            log_tools.log_error('获取大事件时解析token错误')
            return JsonResponse({"code":1315,"data":"[FUN ERROR] Parse token error"}) 
        log_tools.log_request(user_info['username'],'获取工程预警信息',request.GET)
        try:
            year = int(year)
            month = int(month)
            day = int(day)
        except Exception as e:
            log_tools.log_error(traceback.format_exc())
            return JsonResponse({"code":1302,"data":"ERROR: Args type error"})
        month_info = calendar.monthrange(year,month)
        firstDay,max_day = month_info[0],month_info[1]
        if firstDay==0:
            firstDay=7
        date_begin = year*10000+month*100
        date_end = year*10000+month*100+max_day
        total,already,ontime,unfinish=0,0,0,0
        datecolors = {}
        memoMes = {}
        nmemoMes = {}
        res = {
            "code":1013,
            "data":{
                # 选择的时间
                "year":year,"month":month,"day":day,"isToday":get_today(),
                "maxDay":max_day,"firstDay":firstDay,
                "curMonthNode": {"total":total,"already":already,"ontime":ontime,"unfinish":unfinish},
                "datecolors": datecolors,
                "memoMes": memoMes,
                "nmemoMes": nmemoMes
            }
        }
        relations = RelationInfo.objects.filter(userID=user_info['userid'])
        infos = 'none'
        for rela in relations:
            projectId = rela.projectID
            project = ProjectInfo.objects.get(projectID=projectId)
            if project.deleted:
                continue
            infos_single = NodeInfo.objects.filter(nodeID__startswith=projectId,deadline__range=(date_begin,date_end))
            if infos=='none':
                infos = infos_single
            else:
                infos = infos | infos_single
        deleted_project = []
        if infos:
            total = len(infos)
            for d in range(1,max_day+1):
                date = '{}.{}.{}'.format(year,month,d)
                memoMes[date] = []
                nmemoMes[date] = {}
            for info in infos:
                # 基础信息对应的六个时间不需要在工期预警展示
                if info.nodeID<=100000:
                    total-=1
                    continue
                finish_time = info.finishTime
                deadline = get_date(info.deadline)
                full_info,_ = get_full_info(info,'event')
                if full_info=='error':
                    log_tools.log_error('获取大事件时获取完整信息错误')
                    return JsonResponse({"code":1303,"data":"[FUN ERROR] Get data from db error"})
                if not finish_time:
                    # 未完成
                    status = 0
                    unfinish+=1
                else:
                    finish_time = finish_time//10000
                    if finish_time>int(info.deadline):
                        # 延期完成
                        status = 2
                        already+=1
                    else:
                        # 按时完成
                        status = 1
                        ontime += 1
                project_id = int(str(info.nodeID)[:4])
                if project_id not in nmemoMes[deadline]:
                    project = ProjectInfo.objects.get(projectID=project_id)
                    nmemoMes[deadline][project_id] = {'projectName':project.projectName,'msg':[]}
                memoMes[deadline].append({"eventMsg":full_info, "color":COLORS[status]})
                nmemoMes[deadline][project_id]['msg'].append({"eventMsg":full_info, "color":COLORS[status]})
                if deadline not in datecolors:
                    datecolors[deadline] = COLORS[status]
                else:
                    old_status = COLORS[datecolors[deadline]]
                    if old_status!=0 and old_status>status:
                        datecolors[deadline] = COLORS[status]
            res["data"]['curMonthNode']['total'] = total
            res["data"]['curMonthNode']['already'] = already
            res["data"]['curMonthNode']['ontime'] = ontime
            res["data"]['curMonthNode']['unfinish'] = unfinish
            res["data"]['datecolors'] = datecolors
            # res["data"]['memoMes'] = memoMes
            res["data"]['nmemoMes'] = nmemoMes
        log_tools.log_response(res)
        return JsonResponse(res)