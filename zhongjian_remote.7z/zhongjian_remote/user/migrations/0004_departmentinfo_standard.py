# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0003_auto_20210411_1437'),
    ]

    operations = [
        migrations.AddField(
            model_name='departmentinfo',
            name='standard',
            field=models.IntegerField(verbose_name='标配人数', db_index=True, default=0),
            preserve_default=False,
        ),
    ]
