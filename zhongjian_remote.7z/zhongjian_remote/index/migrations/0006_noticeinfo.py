# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0005_auto_20210411_1437'),
    ]

    operations = [
        migrations.CreateModel(
            name='noticeInfo',
            fields=[
                ('insertData', models.DateTimeField(verbose_name='数据创建时间', auto_now_add=True)),
                ('updateData', models.DateTimeField(verbose_name='数据修改时间', db_index=True, default=django.utils.timezone.now)),
                ('noticeID', models.IntegerField(verbose_name='消息编号', primary_key=True, unique=True, db_index=True, serialize=False)),
                ('noticeMsg', models.CharField(verbose_name='消息内容', max_length=40, unique=True)),
                ('projectID', models.IntegerField(verbose_name='项目编号')),
            ],
            options={
                'abstract': False,
            },
        ),
    ]
