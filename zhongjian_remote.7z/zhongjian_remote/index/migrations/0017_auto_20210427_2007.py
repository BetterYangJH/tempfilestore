# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0016_auto_20210427_2005'),
    ]

    operations = [
        migrations.AlterField(
            model_name='phaseinfo',
            name='singelID',
            field=models.BigIntegerField(verbose_name='所属单体', db_index=True),
        ),
    ]
