# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('index', '0011_auto_20210424_2221'),
    ]

    operations = [
        migrations.AlterField(
            model_name='nodeinfo',
            name='finishTime',
            field=models.BigIntegerField(verbose_name='完成时间', null=True),
        ),
    ]
